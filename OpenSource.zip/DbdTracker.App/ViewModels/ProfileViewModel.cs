using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using DbdTracker.App.Localization;
using DbdTracker.App.Models;
using DbdTracker.App.Services;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Media.Imaging;

namespace DbdTracker.App.ViewModels;

public sealed class StatCardViewModel(string label, string valueText, string caption = "")
{
    public string Label { get; } = label;
    public string ValueText { get; } = valueText;
    public string Caption { get; } = caption;
}

public sealed class StatGroupViewModel(string title, IReadOnlyList<StatCardViewModel> items)
{
    public string Title { get; } = title;
    public IReadOnlyList<StatCardViewModel> Items { get; } = items;
}

public sealed class AchievementViewModel
{
    public AchievementViewModel(string title, string subtitle, string iconUrl, bool unlocked)
    {
        Title = title;
        Subtitle = subtitle;
        Unlocked = unlocked;
        Opacity = unlocked ? 1.0 : 0.35;
        Icon = ProfileViewModel.TryImage(iconUrl, 64);
    }

    public string Title { get; }
    public string Subtitle { get; }
    public bool Unlocked { get; }
    public double Opacity { get; }
    public ImageSource? Icon { get; }
}

public sealed partial class ProfileViewModel : ObservableObject
{
    private static readonly (string ApiName, string Ru, string En)[] MilestoneDefs =
    [
        ("ach_50_escapes", "100 побегов", "100 escapes"),
        ("ach_repair", "100 починенных генераторов", "100 generators repaired"),
        ("ach_skill_check", "500 проверок навыка", "500 skill checks"),
        ("ach_heal", "100 вылеченных состояний", "100 health states healed"),
        ("ach_healdying_or_unhook", "50 спасённых выживших", "50 survivors saved"),
        ("ach_dlc7_survivor_2", "35 открытых ворот", "35 exit gates opened"),
        ("ach_dlc7_survivor_1", "100 открытых сундуков", "100 chests opened"),
        ("ach_dlc3_survivor_2", "100 очищенных тотемов", "100 totems cleansed"),
        ("ach_dlc4_survivor_2", "200 прыжков в погоне", "200 vaults in chase"),
        ("ach_sacrifice_100_campers", "100 жертвоприношений", "100 sacrifices"),
        ("ach_dlc7_killer_2", "30 жертв Одержимости", "30 Obsessions sacrificed"),
        ("ach_sacrifice_4_survivors_iam", "4 жертвы за один матч", "4 sacrifices in one match"),
        ("ach_bloodweb_1m_pts", "1 млн очков крови", "1M bloodpoints"),
        ("ach_camper_rank10", "Серебро I за выжившего", "Survivor Silver I"),
        ("ach_camper_rank05", "Золото I за выжившего", "Survivor Gold I"),
        ("ach_camper_rank01", "Радужный I за выжившего", "Survivor Iridescent I"),
        ("ach_slasher_rank10", "Серебро I за убийцу", "Killer Silver I"),
        ("ach_slasher_rank05", "Золото I за убийцу", "Killer Gold I"),
        ("ach_slasher_rank01", "Радужный I за убийцу", "Killer Iridescent I"),
        ("ach_prestige_lvl1", "Престиж I", "Prestige I"),
        ("ach_prestige_lvl3", "Престиж III", "Prestige III"),
        ("ach_prestige_lvl3_100", "Престиж III-50", "Prestige III-50"),
    ];

    private string? _steamId;

    [ObservableProperty] private bool _isLoading;
    [ObservableProperty] private bool _hasError;
    [ObservableProperty] private string _errorMessage = "";
    [ObservableProperty] private bool _hasProfile;

    [ObservableProperty] private string _name = "";
    [ObservableProperty] private ImageSource? _avatar;
    [ObservableProperty] private string _statusText = "";
    [ObservableProperty] private string _hoursText = "";
    [ObservableProperty] private string _hoursHint = "";
    [ObservableProperty] private bool _hasHoursHint;
    [ObservableProperty] private string _profileUrl = "";
    [ObservableProperty] private string _achievementsUrl = "";
    [ObservableProperty] private string _updatedText = "";

    [ObservableProperty] private bool _hasStats;
    [ObservableProperty] private bool _hasStatsMessage;
    [ObservableProperty] private string _statsMessage = "";

    [ObservableProperty] private bool _hasDetailed;
    [ObservableProperty] private bool _hasDetailedMessage;
    [ObservableProperty] private string _detailedMessage = "";
    [ObservableProperty] private bool _showKeyHint;

    [ObservableProperty] private string _bansText = "";
    [ObservableProperty] private bool _hasBanWarning;
    [ObservableProperty] private bool _hasBansClean;

    [ObservableProperty] private bool _hasNewbieFlag;
    [ObservableProperty] private string _newbieFlag = "";

    [ObservableProperty] private string _survivorAdeptsTitle = "";
    [ObservableProperty] private string _killerAdeptsTitle = "";

    public ObservableCollection<StatGroupViewModel> DetailedGroups { get; } = [];
    public ObservableCollection<StatCardViewModel> Overview { get; } = [];
    public ObservableCollection<AchievementViewModel> Milestones { get; } = [];
    public ObservableCollection<AchievementViewModel> SurvivorAdepts { get; } = [];
    public ObservableCollection<AchievementViewModel> KillerAdepts { get; } = [];
    public ObservableCollection<AchievementViewModel> Recent { get; } = [];

    public Task LoadAsync(string steamId)
    {
        _steamId = steamId;
        return LoadCoreAsync(refresh: false);
    }

    [RelayCommand]
    private Task RefreshAsync() => LoadCoreAsync(refresh: true);

    private async Task LoadCoreAsync(bool refresh)
    {
        if (_steamId is null) return;

        IsLoading = true;
        HasError = false;
        try
        {
            Apply(await AppServices.Players.GetProfileAsync(_steamId, refresh));
        }
        catch (UserFacingException ex)
        {
            ErrorMessage = ex.Message;
            HasError = true;
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException)
        {
            ErrorMessage = L.T("Нет соединения. Проверь интернет и попробуй ещё раз.", "No connection. Check your internet and try again.");
            HasError = true;
        }
        catch (Exception ex)
        {
            App.Log(ex);
            ErrorMessage = $"{ex.GetType().Name}: {ex.Message}";
            HasError = true;
        }
        finally
        {
            IsLoading = false;
        }
    }

    private void Apply(PlayerProfile p)
    {
        var s = p.Summary;
        Name = s.Name;
        Avatar = TryImage(s.AvatarUrl, 0);
        ProfileUrl = s.ProfileUrl;
        AchievementsUrl = $"{s.ProfileUrl}/stats/{AppConfig.DbdAppId}/?tab=achievements";
        StatusText = OnlineText(s.OnlineState) + (s.IsPublic ? "" : L.ProfilePrivate);
        UpdatedText = L.T("Обновлено в ", "Updated at ") + p.FetchedAt.ToString("HH:mm");

        StatsMessage = p.StatsError ?? "";
        HasStatsMessage = StatsMessage.Length > 0;

        Overview.Clear();
        Milestones.Clear();
        SurvivorAdepts.Clear();
        KillerAdepts.Clear();
        Recent.Clear();

        DetailedGroups.Clear();
        ShowKeyHint = !AppServices.Keys.HasKey;
        DetailedMessage = p.DetailedError ?? "";
        if (p.DetailedStats is null && p.LastKnownDate is { } knownDay && p.DetailedError is not null)
            DetailedMessage += " " + PlayerInsights.LastKnownNote(knownDay);
        HasDetailedMessage = DetailedMessage.Length > 0;

        var shown = p.DetailedStats ?? p.LastKnownStats;
        HasDetailed = shown is { Count: > 0 };
        if (shown is not null) FillDetailed(s.SteamId, shown, withTodayGain: p.DetailedStats is not null);

        BansText = PlayerInsights.BansText(p.Bans) ?? "";
        HasBanWarning = p.Bans?.HasAny == true;
        HasBansClean = p.Bans is { HasAny: false };

        var grades = PlayerInsights.GradeCards(p.RawStats);
        if (grades.Count > 0)
            DetailedGroups.Insert(0, new StatGroupViewModel(L.T("Ранги (текущий сезон)", "Grades (current season)"), grades));

        HasStats = p.Stats is not null;
        HoursText = PlayerInsights.HoursText(p, shortForm: false);
        HoursHint = PlayerInsights.HoursHint(p) ?? "";
        HasHoursHint = HoursHint.Length > 0;

        if (p.Stats is { } stats) FillStats(stats, p.TotalHours);

        NewbieFlag = PlayerInsights.NewbieFlag(p) ?? "";
        HasNewbieFlag = NewbieFlag.Length > 0;

        HasProfile = true;
    }

    private void FillDetailed(string steamId, IReadOnlyList<StatGroup> groups, bool withTodayGain)
    {
        var baseline = withTodayGain
            ? AppServices.History.TodayBaseline(steamId)
            : new Dictionary<string, double>();

        foreach (var g in groups)
        {
            var cards = g.Stats.Select(st =>
            {
                var delta = baseline.TryGetValue(st.Key, out var b) ? st.Value - b : 0;
                return new StatCardViewModel(
                    st.Label,
                    L.FormatNumber(st.Value),
                    delta > 0 ? "+" + L.FormatNumber(delta) + L.T(" сегодня", " today") : "");
            }).ToList();
            DetailedGroups.Add(new StatGroupViewModel(g.Title, cards));
        }
    }

    internal static ImageSource? TryImage(string? url, int decodeWidth)
    {
        if (string.IsNullOrWhiteSpace(url) || !Uri.TryCreate(url.Trim(), UriKind.Absolute, out var uri))
            return null;
        var img = new BitmapImage(uri);
        if (decodeWidth > 0) img.DecodePixelWidth = decodeWidth;
        return img;
    }

    private void FillStats(GameStats stats, double? totalHours)
    {
        var all = stats.Achievements;
        var unlocked = all.Where(a => a.Unlocked).ToList();
        var byApi = all
            .Where(a => a.ApiName.Length > 0)
            .GroupBy(a => a.ApiName, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);

        var adepts = all.Where(a => a.Name.StartsWith("Adept ", StringComparison.OrdinalIgnoreCase)).ToList();
        var killerAdepts = adepts.Where(IsKillerAdept).OrderBy(a => a.Name).ToList();
        var survivorAdepts = adepts.Except(killerAdepts).OrderBy(a => a.Name).ToList();

        if (totalHours is { } hours)
            Overview.Add(new StatCardViewModel(L.T("Часы в игре", "Hours played"), hours.ToString("N1", L.Culture)));

        if (all.Count > 0)
        {
            var pct = 100.0 * unlocked.Count / all.Count;
            Overview.Add(new StatCardViewModel(L.SectionAchievements, $"{unlocked.Count} / {all.Count}", pct.ToString("N0", L.Culture) + L.T("% получено", "% unlocked")));
        }

        Overview.Add(new StatCardViewModel(L.T("Адепты выживших", "Survivor adepts"),
            $"{survivorAdepts.Count(a => a.Unlocked)} / {survivorAdepts.Count}"));
        Overview.Add(new StatCardViewModel(L.T("Адепты убийц", "Killer adepts"),
            $"{killerAdepts.Count(a => a.Unlocked)} / {killerAdepts.Count}"));

        var last = unlocked.Where(a => a.UnlockedAt is not null).MaxBy(a => a.UnlockedAt);
        if (last is not null)
            Overview.Add(new StatCardViewModel(L.T("Последнее достижение", "Latest achievement"), L.FormatDate(last.UnlockedAt), last.Name));

        foreach (var (api, ru, en) in MilestoneDefs)
        {
            if (!byApi.TryGetValue(api, out var a)) continue;
            Milestones.Add(new AchievementViewModel(
                L.T(ru, en),
                a.Unlocked ? L.T("Получено ", "Unlocked ") + L.FormatDate(a.UnlockedAt) : L.T("Ещё не получено", "Not unlocked yet"),
                a.IconUrl,
                a.Unlocked));
        }

        foreach (var a in survivorAdepts.OrderByDescending(a => a.Unlocked).ThenBy(a => a.Name))
            SurvivorAdepts.Add(ToAdeptVm(a));
        foreach (var a in killerAdepts.OrderByDescending(a => a.Unlocked).ThenBy(a => a.Name))
            KillerAdepts.Add(ToAdeptVm(a));

        SurvivorAdeptsTitle = L.T("Адепты выживших", "Survivor adepts") + $" · {survivorAdepts.Count(a => a.Unlocked)} / {survivorAdepts.Count}";
        KillerAdeptsTitle = L.T("Адепты убийц", "Killer adepts") + $" · {killerAdepts.Count(a => a.Unlocked)} / {killerAdepts.Count}";

        foreach (var a in unlocked.Where(a => a.UnlockedAt is not null).OrderByDescending(a => a.UnlockedAt).Take(12))
            Recent.Add(new AchievementViewModel(a.Name, L.FormatDate(a.UnlockedAt), a.IconUrl, true));
    }

    private static AchievementViewModel ToAdeptVm(Achievement a) => new(
        a.Name["Adept ".Length..],
        a.Unlocked ? L.FormatDate(a.UnlockedAt) : L.T("нет", "not yet"),
        a.IconUrl,
        a.Unlocked);

    internal static bool IsKillerAdept(Achievement a) =>
        a.Description.Contains("merciless", StringComparison.OrdinalIgnoreCase) ||
        a.Description.Contains("as a killer", StringComparison.OrdinalIgnoreCase) ||
        a.Name.StartsWith("Adept The ", StringComparison.OrdinalIgnoreCase);

    internal static string OnlineText(string state) => state switch
    {
        "online" => L.StatusOnline,
        "in-game" => L.StatusInGame,
        "offline" => L.StatusOffline,
        _ => "",
    };
}
