using DbdTracker.App.Services;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;

namespace DbdTracker.App.Views;

public sealed partial class LoginPage : Page
{
    private CancellationTokenSource? _cts;

    public LoginPage()
    {
        InitializeComponent();
    }

    private async void SignIn_Click(object sender, RoutedEventArgs e)
    {
        ErrorBar.IsOpen = false;
        SetWaiting(true);
        _cts = new CancellationTokenSource();

        try
        {
            var steamId = await AppServices.Auth.SignInAsync(_cts.Token);
            AppServices.Session.SignIn(steamId);
            App.MainWindow?.ShowShell();
        }
        catch (OperationCanceledException)
        {
        }
        catch (Exception ex)
        {
            ErrorBar.Message = ex.Message;
            ErrorBar.IsOpen = true;
        }
        finally
        {
            SetWaiting(false);
            _cts?.Dispose();
            _cts = null;
        }
    }

    private void Guest_Click(object sender, RoutedEventArgs e)
    {
        AppServices.Session.ContinueAsGuest();
        App.MainWindow?.ShowShell();
    }

    private void Cancel_Click(object sender, RoutedEventArgs e) => _cts?.Cancel();

    private void SetWaiting(bool waiting)
    {
        SignInButton.IsEnabled = !waiting;
        GuestButton.IsEnabled = !waiting;
        WaitingPanel.Visibility = waiting ? Visibility.Visible : Visibility.Collapsed;
    }
}
