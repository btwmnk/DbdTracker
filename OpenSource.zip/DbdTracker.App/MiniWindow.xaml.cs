using DbdTracker.App.Services;
using DbdTracker.App.ViewModels;
using Microsoft.UI.Windowing;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using Windows.ApplicationModel.DataTransfer;
using Windows.System;

namespace DbdTracker.App;

public sealed partial class MiniWindow : Window
{
    public MiniViewModel ViewModel { get; } = new();

    private bool _positioned;
    private bool _allowClose;
    private bool _pendingAutoPaste;
    private string? _lastAutoPasted;

    public MiniWindow()
    {
        InitializeComponent();

        ExtendsContentIntoTitleBar = true;
        WindowHelper.StyleCaptionButtons(this);
        SetTitleBar(TitleBarArea);

        if (File.Exists(AppConfig.IconPath))
            AppWindow.SetIcon(AppConfig.IconPath);

        if (AppWindow.Presenter is OverlappedPresenter presenter)
        {
            presenter.IsAlwaysOnTop = true;
            presenter.IsMaximizable = false;
            presenter.IsMinimizable = false;
        }

        WindowHelper.ResizeLogical(this, 440, 640);

        AppWindow.Closing += (_, e) =>
        {
            if (_allowClose) return;
            e.Cancel = true;
            Hide();
        };

        Activated += OnActivated;
    }

    public bool IsShown => AppWindow.IsVisible;

    public void ShowMini()
    {
        if (!_positioned)
        {
            WindowHelper.MoveTopRight(this);
            _positioned = true;
        }

        _pendingAutoPaste = AppServices.Settings.AutoPaste;
        ViewModel.Reapply();
        WindowHelper.BringToFront(this);
        QueryBox.Focus(FocusState.Programmatic);
        QueryBox.SelectAll();
    }

    public void Hide() => AppWindow.Hide();

    public void Toggle()
    {
        if (IsShown) Hide();
        else ShowMini();
    }

    public void ForceClose()
    {
        _allowClose = true;
        Close();
    }

    private async void OnActivated(object sender, WindowActivatedEventArgs args)
    {
        if (args.WindowActivationState == WindowActivationState.Deactivated || !_pendingAutoPaste)
            return;

        _pendingAutoPaste = false;

        var text = await ReadClipboardAsync();
        if (MiniViewModel.LooksLikeSteam(text) && text != _lastAutoPasted)
        {
            _lastAutoPasted = text;
            ViewModel.Query = text!;
            if (ViewModel.SearchCommand.CanExecute(null))
                await ViewModel.SearchCommand.ExecuteAsync(null);
        }
    }

    private static async Task<string?> ReadClipboardAsync()
    {
        try
        {
            var content = Clipboard.GetContent();
            if (content.Contains(StandardDataFormats.Text))
                return (await content.GetTextAsync())?.Trim();
        }
        catch (Exception ex)
        {
            App.Log(ex);
        }
        return null;
    }

    private async void Paste_Click(object sender, RoutedEventArgs e)
    {
        var text = await ReadClipboardAsync();
        if (string.IsNullOrEmpty(text)) return;

        ViewModel.Query = text;
        if (ViewModel.SearchCommand.CanExecute(null))
            await ViewModel.SearchCommand.ExecuteAsync(null);
    }

    private void QueryBox_KeyDown(object sender, KeyRoutedEventArgs e)
    {
        if (e.Key == VirtualKey.Enter && ViewModel.SearchCommand.CanExecute(null))
        {
            ViewModel.SearchCommand.Execute(null);
            e.Handled = true;
        }
    }

    private void Root_KeyDown(object sender, KeyRoutedEventArgs e)
    {
        if (e.Key == VirtualKey.Escape)
        {
            Hide();
            e.Handled = true;
        }
    }

    private async void Recent_Click(object sender, RoutedEventArgs e)
    {
        if (sender is FrameworkElement { Tag: string steamId })
            await ViewModel.OpenRecentAsync(steamId);
    }

    private void ClearRecent_Click(object sender, RoutedEventArgs e) => ViewModel.ClearRecent();

    private void Pin_Click(object sender, RoutedEventArgs e)
    {
        if (AppWindow.Presenter is OverlappedPresenter presenter)
            presenter.IsAlwaysOnTop = PinButton.IsChecked == true;
    }

    private void OpenSettings_Click(object sender, RoutedEventArgs e) => App.MainWindow?.OpenSettingsFromMini();

    private void OpenFull_Click(object sender, RoutedEventArgs e)
    {
        var id = string.IsNullOrEmpty(ViewModel.SteamId) ? null : ViewModel.SteamId;
        App.MainWindow?.OpenFromMini(id);
    }
}
