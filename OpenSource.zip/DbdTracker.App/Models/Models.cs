namespace DbdTracker.App.Models;

public sealed record PlayerSummary(
    string SteamId,
    string Name,
    string AvatarUrl,
    string ProfileUrl,
    string OnlineState,
    bool IsPublic,
    DateOnly? MemberSince = null,
    double? DbdHoursOnRecord = null,
    double? DbdHoursRecent = null);

public sealed record Achievement(
    string ApiName,
    string Name,
    string Description,
    string IconUrl,
    bool Unlocked,
    DateTimeOffset? UnlockedAt);

public sealed record GameStats(
    double? RecentHours,
    IReadOnlyList<Achievement> Achievements);

public sealed record Stat(string Key, string Label, double Value);

public sealed record StatGroup(string Title, IReadOnlyList<Stat> Stats);

public sealed record PlayerProfile(
    PlayerSummary Summary,
    GameStats? Stats,
    string? StatsError,
    IReadOnlyList<StatGroup>? DetailedStats,
    string? DetailedError,
    DateTimeOffset FetchedAt,
    double? TotalHours = null,
    double? RecentHours = null,
    IReadOnlyDictionary<string, double>? RawStats = null,
    PlayerBans? Bans = null,
    DateOnly? LastKnownDate = null,
    IReadOnlyList<StatGroup>? LastKnownStats = null);

public sealed record PlayerBans(
    bool VacBanned,
    int VacBans,
    int GameBans,
    int DaysSinceLastBan,
    bool CommunityBanned,
    bool TradeBanned)
{
    public bool HasAny => VacBanned || VacBans > 0 || GameBans > 0 || CommunityBanned || TradeBanned;
}

public sealed record Playtime(double? TotalHours, double? RecentHours);

public sealed class UserFacingException(string message) : Exception(message);
