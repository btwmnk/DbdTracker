using DbdTracker.App.Localization;
using DbdTracker.App.Services;

namespace DbdTracker.App.ViewModels;

public static class MiniStatOptions
{
    public const string GradeSurvivor = "grade_survivor";
    public const string GradeKiller = "grade_killer";
    public const string Achievements = "achievements";
    public const string AdeptsSurvivor = "adepts_survivor";
    public const string AdeptsKiller = "adepts_killer";

    public const int BigCards = 4;

    public static List<string> Defaults() =>
    [
        GradeSurvivor,
        GradeKiller,
        "DBD_Escape",
        "DBD_GeneratorPct_float",
        "DBD_DLC7_Camper_Stat1",
        "DBD_UnhookOrHeal",
        "DBD_SkillCheckSuccess",
        "DBD_DLC3_Camper_Stat1",
        Achievements,
    ];

    public static IEnumerable<(string Key, string Label, string GroupTitle)> All()
    {
        var special = L.T("Ранги и достижения", "Grades and achievements");
        yield return (GradeSurvivor, L.T("Ранг выжившего", "Survivor grade"), special);
        yield return (GradeKiller, L.T("Ранг убийцы", "Killer grade"), special);
        yield return (Achievements, L.SectionAchievements, special);
        yield return (AdeptsSurvivor, L.T("Адепты выживших", "Survivor adepts"), special);
        yield return (AdeptsKiller, L.T("Адепты убийц", "Killer adepts"), special);

        foreach (var item in StatCatalog.All)
            yield return item;
    }
}
