using DbdTracker.App.Localization;
using DbdTracker.App.Services;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media.Animation;
using Microsoft.UI.Xaml.Navigation;

namespace DbdTracker.App.Views;

public sealed partial class ShellPage : Page
{
    private string? _startPage;

    public ShellPage()
    {
        InitializeComponent();
        Loaded += OnLoaded;
    }

    private string? MySteamId => AppServices.Session.SteamId;

    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
        base.OnNavigatedTo(e);
        _startPage = e.Parameter as string;
    }

    private void OnLoaded(object sender, RoutedEventArgs e)
    {
        MyProfileItem.Visibility = MySteamId is null ? Visibility.Collapsed : Visibility.Visible;
        SignOutItem.Content = MySteamId is null ? L.NavSignIn : L.NavSignOut;

        var start = _startPage;
        _startPage = null;

        if (start?.StartsWith("profile:", StringComparison.Ordinal) == true)
        {
            OpenProfile(start["profile:".Length..]);
            return;
        }

        if (ContentFrame.Content is not null) return;

        NavView.SelectedItem = start == "settings" ? SettingsItem
            : MySteamId is null ? SearchItem
            : MyProfileItem;
    }

    public void OpenSettings() => NavView.SelectedItem = SettingsItem;

    public void OpenProfile(string steamId)
    {
        if (ContentFrame.Content is ProfilePage page && page.SteamId == steamId) return;
        ContentFrame.Navigate(typeof(ProfilePage), steamId, new DrillInNavigationTransitionInfo());
    }

    private void NavView_SelectionChanged(NavigationView sender, NavigationViewSelectionChangedEventArgs args)
    {
        if (args.SelectedItem is not NavigationViewItem item) return;

        if (item == MyProfileItem && MySteamId is not null && !IsShowingMyProfile())
            ContentFrame.Navigate(typeof(ProfilePage), MySteamId, args.RecommendedNavigationTransitionInfo);
        else if (item == SearchItem && ContentFrame.CurrentSourcePageType != typeof(SearchPage))
            ContentFrame.Navigate(typeof(SearchPage), null, args.RecommendedNavigationTransitionInfo);
        else if (item == SettingsItem && ContentFrame.CurrentSourcePageType != typeof(SettingsPage))
            ContentFrame.Navigate(typeof(SettingsPage), null, args.RecommendedNavigationTransitionInfo);
    }

    private void NavView_ItemInvoked(NavigationView sender, NavigationViewItemInvokedEventArgs args)
    {
        if (args.InvokedItemContainer == SignOutItem)
            App.MainWindow?.SignOut();
        else if (args.InvokedItemContainer == MiniItem)
            App.MainWindow?.SwitchToMini();
    }

    private void NavView_BackRequested(NavigationView sender, NavigationViewBackRequestedEventArgs args)
    {
        if (ContentFrame.CanGoBack)
            ContentFrame.GoBack(new SlideNavigationTransitionInfo { Effect = SlideNavigationTransitionEffect.FromLeft });
    }

    private void ContentFrame_Navigated(object sender, NavigationEventArgs e)
    {
        NavView.IsBackEnabled = ContentFrame.CanGoBack;

        NavView.SelectedItem =
            e.SourcePageType == typeof(SearchPage) ? SearchItem :
            e.SourcePageType == typeof(SettingsPage) ? SettingsItem :
            e.SourcePageType == typeof(ProfilePage) && e.Parameter as string == MySteamId && MySteamId is not null ? MyProfileItem :
            null;
    }

    private bool IsShowingMyProfile() =>
        ContentFrame.Content is ProfilePage page && page.SteamId == MySteamId;
}
