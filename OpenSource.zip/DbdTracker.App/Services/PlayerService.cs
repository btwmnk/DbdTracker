using DbdTracker.App.Localization;
using DbdTracker.App.Models;

namespace DbdTracker.App.Services;

public sealed class PlayerService
{
    private static readonly TimeSpan Ttl = TimeSpan.FromMinutes(2);

    private readonly SteamCommunityClient _community;
    private readonly SteamWebApiClient _webApi;
    private readonly ApiKeyStore _keys;
    private readonly HistoryStore _history;
    private readonly Dictionary<string, PlayerProfile> _cache = [];

    public PlayerService(SteamCommunityClient community, SteamWebApiClient webApi, ApiKeyStore keys, HistoryStore history)
    {
        _history = history;
        _community = community;
        _webApi = webApi;
        _keys = keys;
        _keys.Changed += (_, _) => _cache.Clear();
    }

    public void ClearCache() => _cache.Clear();

    public Task<string> ResolveAsync(string input, CancellationToken ct = default) =>
        _community.ResolveAsync(input, ct);

    public async Task<PlayerProfile> GetProfileAsync(string steamId, bool refresh, CancellationToken ct = default)
    {
        if (!refresh && _cache.TryGetValue(steamId, out var cached) && DateTimeOffset.Now - cached.FetchedAt < Ttl)
            return cached;

        var summaryTask = _community.GetSummaryAsync(steamId, ct);
        var statsTask = Capture(_community.GetDbdStatsAsync(steamId, ct));
        var detailedTask = _keys.HasKey
            ? Capture(_webApi.GetDbdStatsAsync(steamId, ct))
            : Task.FromResult<(Dictionary<string, double>?, string?)>((null, null));

        var playtimeTask = _keys.HasKey
            ? _webApi.GetDbdPlaytimeAsync(steamId, ct)
            : Task.FromResult<Playtime?>(null);

        var bansTask = _keys.HasKey
            ? _webApi.GetBansAsync(steamId, ct)
            : Task.FromResult<PlayerBans?>(null);

        await Task.WhenAll(summaryTask, statsTask, detailedTask, playtimeTask, bansTask);

        var summary = await summaryTask;
        var (stats, statsError) = await statsTask;
        var (raw, detailedError) = await detailedTask;
        var playtime = await playtimeTask;
        var bans = await bansTask;

        DateOnly? lastKnownDate = null;
        IReadOnlyList<StatGroup>? lastKnownStats = null;
        if (raw is null && _history.LastKnown(steamId) is { } known)
        {
            lastKnownDate = known.Day;
            lastKnownStats = StatCatalog.Build(known.Values, alreadyScaled: true);
        }

        var totalHours = playtime?.TotalHours ?? summary.DbdHoursOnRecord;
        var recentHours = playtime?.RecentHours ?? summary.DbdHoursRecent ?? stats?.RecentHours;

        var profile = new PlayerProfile(
            summary,
            stats,
            statsError,
            raw is null ? null : StatCatalog.Build(raw),
            detailedError,
            DateTimeOffset.Now,
            totalHours,
            recentHours,
            raw,
            bans,
            lastKnownDate,
            lastKnownStats);

        RecordHistory(profile);

        _cache[steamId] = profile;
        return profile;
    }

    private void RecordHistory(PlayerProfile profile)
    {
        var values = new Dictionary<string, double>();

        if (profile.DetailedStats is { } groups)
        {
            foreach (var st in groups.SelectMany(g => g.Stats))
                values.TryAdd(st.Key, st.Value);
        }

        try
        {
            _history.Record(profile.Summary.SteamId, values);
        }
        catch (Exception ex)
        {
            App.Log(ex);
        }
    }

    private static async Task<(T?, string?)> Capture<T>(Task<T> task) where T : class
    {
        try
        {
            return (await task, null);
        }
        catch (UserFacingException ex)
        {
            return (null, ex.Message);
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException)
        {
            return (null, L.T("Нет соединения со Steam.", "No connection to Steam."));
        }
        catch (Exception ex)
        {
            App.Log(ex);
            return (null, L.T("Не удалось разобрать ответ Steam: ", "Could not parse Steam response: ") + ex.Message);
        }
    }
}
