using DbdTracker.App.Localization;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using DbdTracker.App.Models;
using DbdTracker.App.Services;

namespace DbdTracker.App.ViewModels;

public sealed partial class SearchViewModel : ObservableObject
{
    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(SearchCommand))]
    private string _query = "";

    [ObservableProperty] private bool _isBusy;
    [ObservableProperty] private bool _hasError;
    [ObservableProperty] private string _errorMessage = "";

    public event EventHandler<string>? PlayerFound;

    private bool CanSearch() => !string.IsNullOrWhiteSpace(Query);

    [RelayCommand(CanExecute = nameof(CanSearch))]
    private async Task SearchAsync()
    {
        IsBusy = true;
        HasError = false;
        try
        {
            var steamId = await AppServices.Players.ResolveAsync(Query);
            PlayerFound?.Invoke(this, steamId);
        }
        catch (UserFacingException ex)
        {
            ErrorMessage = ex.Message;
            HasError = true;
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException)
        {
            ErrorMessage = L.T("Нет соединения со Steam. Проверь интернет.", "No connection to Steam. Check your internet connection.");
            HasError = true;
        }
        finally
        {
            IsBusy = false;
        }
    }
}
