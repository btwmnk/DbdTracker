namespace DbdTracker.App.Services;

public sealed class SessionStore
{
    private readonly string _path = Path.Combine(AppConfig.DataFolder, "session.txt");

    public string? SteamId { get; private set; }

    public bool IsGuest { get; private set; }

    public bool HasSession => SteamId is not null || IsGuest;

    public SessionStore()
    {
        try
        {
            if (File.Exists(_path))
            {
                var value = File.ReadAllText(_path).Trim();
                if (value == "guest") IsGuest = true;
                else if (value.Length == 17) SteamId = value;
            }
        }
        catch (IOException) { }
    }

    public void SignIn(string steamId) => Write(steamId, guest: false);

    public void ContinueAsGuest() => Write(null, guest: true);

    public void SignOut()
    {
        SteamId = null;
        IsGuest = false;
        try { File.Delete(_path); } catch (IOException) { }
    }

    private void Write(string? steamId, bool guest)
    {
        SteamId = steamId;
        IsGuest = guest;
        try
        {
            Directory.CreateDirectory(AppConfig.DataFolder);
            File.WriteAllText(_path, guest ? "guest" : steamId);
        }
        catch (IOException) { }
    }
}
