using System.Text.Json;

namespace DbdTracker.App.Services;

public sealed record RecentPlayer(string SteamId, string Name, string AvatarUrl);

public sealed class RecentPlayersStore
{
    private const int Max = 8;
    private readonly string _path = Path.Combine(AppConfig.DataFolder, "recent.json");
    private List<RecentPlayer> _items;

    public RecentPlayersStore()
    {
        try
        {
            _items = File.Exists(_path)
                ? JsonSerializer.Deserialize<List<RecentPlayer>>(File.ReadAllText(_path)) ?? []
                : [];
        }
        catch (Exception ex) when (ex is IOException or JsonException or UnauthorizedAccessException)
        {
            _items = [];
        }
    }

    public IReadOnlyList<RecentPlayer> Items => _items;

    public void Add(RecentPlayer player)
    {
        _items.RemoveAll(p => p.SteamId == player.SteamId);
        _items.Insert(0, player);
        if (_items.Count > Max) _items.RemoveRange(Max, _items.Count - Max);
        Save();
    }

    public void Clear()
    {
        _items.Clear();
        Save();
    }

    private void Save()
    {
        try
        {
            Directory.CreateDirectory(AppConfig.DataFolder);
            File.WriteAllText(_path, JsonSerializer.Serialize(_items));
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
        }
    }
}
