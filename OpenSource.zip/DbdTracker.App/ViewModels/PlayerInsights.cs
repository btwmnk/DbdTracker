using DbdTracker.App.Localization;
using DbdTracker.App.Models;
using DbdTracker.App.Services;

namespace DbdTracker.App.ViewModels;

public static class PlayerInsights
{
    private const double NewbieHours = 100;

    private const int NewAccountDays = 180;

    private const double FewAchievementsShare = 0.05;

    public static string? NewbieFlag(PlayerProfile p)
    {
        var reasons = new List<string>();

        if (p.TotalHours is { } h && h < NewbieHours)
            reasons.Add(L.T($"всего {h.ToString("N1", L.Culture)} ч в DBD", $"only {h.ToString("N1", L.Culture)} h in DBD"));

        if (p.Summary.MemberSince is { } since)
        {
            var age = DateOnly.FromDateTime(DateTime.Now).DayNumber - since.DayNumber;
            if (age is >= 0 and < NewAccountDays)
                reasons.Add(L.T(
                    $"аккаунт Steam создан {since.ToString("d MMM yyyy", L.Culture)}",
                    $"Steam account created {since.ToString("MMM d, yyyy", L.Culture)}"));
        }

        if (p.Stats is { Achievements.Count: > 0 } stats)
        {
            var unlocked = stats.Achievements.Count(a => a.Unlocked);
            if ((double)unlocked / stats.Achievements.Count < FewAchievementsShare)
                reasons.Add(L.T(
                    $"почти нет достижений ({unlocked} из {stats.Achievements.Count})",
                    $"almost no achievements ({unlocked} of {stats.Achievements.Count})"));
        }

        if (reasons.Count == 0) return null;
        return L.T("Новичок или новый аккаунт: ", "New player or new account: ") + string.Join(", ", reasons);
    }

    public static string LastKnownNote(DateOnly day) => L.T(
        $"Ниже — последние сохранённые данные от {day.ToString("d MMM yyyy", L.Culture)}, когда профиль был открыт.",
        $"Below are the last saved numbers from {day.ToString("MMM d, yyyy", L.Culture)}, when the profile was public.");

    public static string? BansText(PlayerBans? b)
    {
        if (b is null) return null;
        if (!b.HasAny) return L.T("Банов в Steam нет", "No Steam bans");

        var parts = new List<string>();
        if (b.VacBans > 0 || b.VacBanned) parts.Add(L.T("VAC-бан", "VAC ban") + $" ×{Math.Max(1, b.VacBans)}");
        if (b.GameBans > 0) parts.Add(L.T("игровой бан", "game ban") + $" ×{b.GameBans}");
        if (b.CommunityBanned) parts.Add(L.T("бан в сообществе", "community ban"));
        if (b.TradeBanned) parts.Add(L.T("запрет обмена", "trade ban"));
        if ((b.VacBans > 0 || b.GameBans > 0) && b.DaysSinceLastBan > 0)
            parts.Add(L.T($"последний {b.DaysSinceLastBan} дн. назад", $"last {b.DaysSinceLastBan} days ago"));

        return string.Join(" · ", parts);
    }

    public static string HoursText(PlayerProfile p, bool shortForm)
    {
        var parts = new List<string>();

        if (p.TotalHours is { } total)
            parts.Add(total.ToString("N1", L.Culture) + (shortForm ? L.T(" ч в DBD", " h in DBD") : L.T(" ч в Dead by Daylight", " h in Dead by Daylight")));
        else
            parts.Add(L.T("Всего часов: неизвестно", "Total hours: unknown"));

        if (p.RecentHours is { } recent)
            parts.Add(recent.ToString("N1", L.Culture) + L.T(" ч за 2 недели", " h last 2 weeks"));

        return string.Join(" · ", parts);
    }

    public static string? HoursHint(PlayerProfile p) =>
        p.TotalHours is not null ? null
        : AppServices.Keys.HasKey
            ? L.T("Steam не отдал общее время: у игрока скрыты «Сведения об играх» или время в игре.",
                  "Steam didn't return total playtime: the player hides game details or playtime.")
            : L.T("Без ключа Steam API общее время видно, только если игрок запускал DBD в последние 2 недели. С ключом — всегда (если профиль открыт).",
                  "Without a Steam API key, total hours are only visible if the player launched DBD in the last 2 weeks. With a key — always (if the profile is public).");

    private static readonly int[] PipsToNext = [3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5];

    public const string SurvivorPipsKey = "DBD_CamperSkulls";
    public static readonly string[] KillerPipsKeys = ["DBD_KillerSkulls", "DBD_SlasherSkulls"];

    public static (string Grade, string Progress) GradeFromPips(double pips)
    {
        var left = Math.Max(0, (int)pips);
        var index = 0;
        while (index < PipsToNext.Length && left >= PipsToNext[index])
        {
            left -= PipsToNext[index];
            index++;
        }

        string[] tiersRu = ["Пепел", "Бронза", "Серебро", "Золото", "Радужный"];
        string[] tiersEn = ["Ash", "Bronze", "Silver", "Gold", "Iridescent"];
        string[] numerals = ["IV", "III", "II", "I"];

        var tier = Math.Min(index / 4, 4);
        var grade = $"{L.T(tiersRu[tier], tiersEn[tier])} {numerals[index % 4]}";

        var progress = index < PipsToNext.Length
            ? $"{left} / {PipsToNext[index]}" + L.T(" пипов", " pips")
            : L.T("максимальный ранг", "max grade");

        return (grade, progress);
    }

    public static List<StatCardViewModel> GradeCards(IReadOnlyDictionary<string, double>? raw)
    {
        var cards = new List<StatCardViewModel>();
        if (raw is null) return cards;

        if (raw.TryGetValue(SurvivorPipsKey, out var sp))
        {
            var (g, pr) = GradeFromPips(sp);
            cards.Add(new StatCardViewModel(L.T("Ранг выжившего", "Survivor grade"), g, pr));
        }

        foreach (var key in KillerPipsKeys)
        {
            if (!raw.TryGetValue(key, out var kp)) continue;
            var (g, pr) = GradeFromPips(kp);
            cards.Add(new StatCardViewModel(L.T("Ранг убийцы", "Killer grade"), g, pr));
            break;
        }

        return cards;
    }
}
