namespace DbdTracker.App.Services;

public static class AppServices
{
    private static readonly HttpClient Http = CreateHttp();

    public static SessionStore Session { get; } = new();
    public static ApiKeyStore Keys { get; } = new();
    public static AuthService Auth { get; } = new(Http);
    public static SteamWebApiClient WebApi { get; } = new(Http, Keys);
    public static HistoryStore History { get; } = new();
    public static PlayerService Players { get; } = new(new SteamCommunityClient(Http), WebApi, Keys, History);
    public static AppSettings Settings { get; } = AppSettings.Load();
    public static RecentPlayersStore Recent { get; } = new();

    private static HttpClient CreateHttp()
    {
        var http = new HttpClient { Timeout = TimeSpan.FromSeconds(20) };
        http.DefaultRequestHeaders.UserAgent.ParseAdd(AppConfig.UserAgent);

        http.DefaultRequestHeaders.AcceptLanguage.ParseAdd("en");
        return http;
    }
}
