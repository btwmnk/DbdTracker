using System.Globalization;
using System.Text.Json;

namespace DbdTracker.App.Services;

public sealed class HistoryStore
{
    public const string HoursKey = "hours_total";

    private const int KeepDays = 400;

    private sealed class DayEntry
    {
        public Dictionary<string, double> First { get; set; } = [];
        public Dictionary<string, double> Last { get; set; } = [];
    }

    private readonly string _folder = Path.Combine(AppConfig.DataFolder, "history_v2");
    private readonly Dictionary<string, SortedDictionary<DateOnly, DayEntry>> _cache = [];

    public void Record(string steamId, IReadOnlyDictionary<string, double> values)
    {
        if (values.Count == 0) return;

        var days = Load(steamId);
        var today = DateOnly.FromDateTime(DateTime.Now);
        if (!days.TryGetValue(today, out var entry))
            days[today] = entry = new DayEntry();

        foreach (var (key, value) in values)
        {
            entry.First.TryAdd(key, value);
            entry.Last[key] = value;
        }

        var cutoff = today.AddDays(-KeepDays);
        foreach (var old in days.Keys.Where(d => d < cutoff).ToList())
            days.Remove(old);

        Save(steamId, days);
    }

    public IReadOnlyDictionary<string, double> TodayBaseline(string steamId) =>
        Load(steamId).TryGetValue(DateOnly.FromDateTime(DateTime.Now), out var e)
            ? e.First
            : new Dictionary<string, double>();

    public (DateOnly Day, IReadOnlyDictionary<string, double> Values)? LastKnown(string steamId)
    {
        foreach (var (day, entry) in Load(steamId).Reverse())
        {
            var values = entry.Last
                .Where(kv => kv.Key != HoursKey)
                .ToDictionary(kv => kv.Key, kv => kv.Value);
            if (values.Count > 0) return (day, values);
        }
        return null;
    }

    private SortedDictionary<DateOnly, DayEntry> Load(string steamId)
    {
        if (_cache.TryGetValue(steamId, out var cached)) return cached;

        var days = new SortedDictionary<DateOnly, DayEntry>();
        try
        {
            var path = PathFor(steamId);
            if (File.Exists(path))
            {
                var raw = JsonSerializer.Deserialize<Dictionary<string, DayEntry>>(File.ReadAllText(path)) ?? [];
                foreach (var (k, v) in raw)
                {
                    if (DateOnly.TryParseExact(k, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var d))
                        days[d] = v;
                }
            }
        }
        catch (Exception ex) when (ex is IOException or JsonException or UnauthorizedAccessException)
        {
        }

        _cache[steamId] = days;
        return days;
    }

    private void Save(string steamId, SortedDictionary<DateOnly, DayEntry> days)
    {
        try
        {
            Directory.CreateDirectory(_folder);
            var raw = days.ToDictionary(kv => kv.Key.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture), kv => kv.Value);
            File.WriteAllText(PathFor(steamId), JsonSerializer.Serialize(raw));
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
        }
    }

    private string PathFor(string steamId) => Path.Combine(_folder, $"{steamId}.json");
}
