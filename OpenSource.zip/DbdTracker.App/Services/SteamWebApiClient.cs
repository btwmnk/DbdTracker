using DbdTracker.App.Localization;
using System.Net;
using System.Text.Json;
using DbdTracker.App.Models;

namespace DbdTracker.App.Services;

public sealed class SteamWebApiClient(HttpClient http, ApiKeyStore keys)
{
    private const string Base = "https://api.steampowered.com/";

    public async Task<bool> ValidateKeyAsync(string key, CancellationToken ct = default)
    {
        var url = $"{Base}ISteamUser/GetPlayerSummaries/v2/?key={Uri.EscapeDataString(key.Trim())}&steamids=76561197960287930";
        try
        {
            using var resp = await http.GetAsync(url, ct);
            return resp.IsSuccessStatusCode;
        }
        catch (HttpRequestException)
        {
            throw new UserFacingException(L.T("Нет соединения со Steam. Проверь интернет.", "No connection to Steam. Check your internet connection."));
        }
    }

    public async Task<Playtime?> GetDbdPlaytimeAsync(string steamId, CancellationToken ct = default)
    {
        var key = keys.Key;
        if (string.IsNullOrEmpty(key)) return null;

        var url = $"{Base}IPlayerService/GetOwnedGames/v1/?key={Uri.EscapeDataString(key)}&steamid={steamId}" +
                  $"&include_played_free_games=1&appids_filter%5B0%5D={AppConfig.DbdAppId}";
        try
        {
            using var resp = await http.GetAsync(url, ct);
            if (!resp.IsSuccessStatusCode) return null;

            using var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
            if (!doc.RootElement.TryGetProperty("response", out var r) ||
                !r.TryGetProperty("games", out var games) || games.ValueKind != JsonValueKind.Array)
                return null;

            foreach (var g in games.EnumerateArray())
            {
                if (!g.TryGetProperty("appid", out var app) || app.GetInt32() != AppConfig.DbdAppId) continue;

                double? total = g.TryGetProperty("playtime_forever", out var f) ? f.GetDouble() / 60.0 : null;
                double? recent = g.TryGetProperty("playtime_2weeks", out var w) ? w.GetDouble() / 60.0 : 0;
                return new Playtime(total, recent);
            }
        }
        catch (Exception ex) when (ex is HttpRequestException or JsonException or InvalidOperationException)
        {
        }
        return null;
    }

    public async Task<PlayerBans?> GetBansAsync(string steamId, CancellationToken ct = default)
    {
        var key = keys.Key;
        if (string.IsNullOrEmpty(key)) return null;

        var url = $"{Base}ISteamUser/GetPlayerBans/v1/?key={Uri.EscapeDataString(key)}&steamids={steamId}";
        try
        {
            using var resp = await http.GetAsync(url, ct);
            if (!resp.IsSuccessStatusCode) return null;

            using var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
            if (!doc.RootElement.TryGetProperty("players", out var players) ||
                players.ValueKind != JsonValueKind.Array || players.GetArrayLength() == 0)
                return null;

            var p = players[0];
            bool B(string name) => p.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.True;
            int I(string name) => p.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.Number ? v.GetInt32() : 0;
            var economy = p.TryGetProperty("EconomyBan", out var e) ? e.GetString() : "none";

            return new PlayerBans(
                VacBanned: B("VACBanned"),
                VacBans: I("NumberOfVACBans"),
                GameBans: I("NumberOfGameBans"),
                DaysSinceLastBan: I("DaysSinceLastBan"),
                CommunityBanned: B("CommunityBanned"),
                TradeBanned: !string.IsNullOrEmpty(economy) && economy != "none");
        }
        catch (Exception ex) when (ex is HttpRequestException or JsonException or InvalidOperationException)
        {
            return null;
        }
    }

    public async Task<Dictionary<string, double>> GetDbdStatsAsync(string steamId, CancellationToken ct = default)
    {
        var key = keys.Key ?? throw new UserFacingException(L.T("Ключ Steam API не задан.", "Steam API key is not set."));
        var url = $"{Base}ISteamUserStats/GetUserStatsForGame/v2/?appid={AppConfig.DbdAppId}" +
                  $"&key={Uri.EscapeDataString(key)}&steamid={steamId}";

        HttpResponseMessage resp;
        try
        {
            resp = await http.GetAsync(url, ct);
        }
        catch (HttpRequestException)
        {
            throw new UserFacingException(L.T("Steam API недоступен. Проверь интернет.", "Steam API is unreachable. Check your internet connection."));
        }

        using (resp)
        {
            var body = await resp.Content.ReadAsStringAsync(ct);

            if (resp.StatusCode == HttpStatusCode.Forbidden && body.Contains("key", StringComparison.OrdinalIgnoreCase))
                throw new UserFacingException(L.T("Steam не принял ключ API. Проверь его в Настройках.", "Steam rejected the API key. Check it in Settings."));

            if (resp.StatusCode is HttpStatusCode.Forbidden or HttpStatusCode.BadRequest or HttpStatusCode.Unauthorized)
                throw new UserFacingException(L.T("Игрок скрыл «Сведения об играх» в Steam — эту статистику не видит ни одна программа или сайт. Открыть её может только сам игрок (Профиль → Приватность).", "The player hides \"Game details\" on Steam — no app or website can see these stats. Only the player can make them public (Profile → Privacy)."));

            if (resp.StatusCode == HttpStatusCode.TooManyRequests)
                throw new UserFacingException(L.T("Слишком много запросов к Steam. Подожди минуту.", "Too many requests to Steam. Wait a minute."));

            if (!resp.IsSuccessStatusCode)
                throw new UserFacingException(L.T("Steam API вернул ошибку", "Steam API returned an error") + $" ({(int)resp.StatusCode}).");

            var result = new Dictionary<string, double>(StringComparer.Ordinal);
            try
            {
                using var doc = JsonDocument.Parse(body);
                if (doc.RootElement.TryGetProperty("playerstats", out var ps) &&
                    ps.TryGetProperty("stats", out var stats) &&
                    stats.ValueKind == JsonValueKind.Array)
                {
                    foreach (var s in stats.EnumerateArray())
                    {
                        if (s.TryGetProperty("name", out var n) && s.TryGetProperty("value", out var v) &&
                            v.ValueKind == JsonValueKind.Number)
                            result[n.GetString() ?? ""] = v.GetDouble();
                    }
                }
            }
            catch (JsonException)
            {
                throw new UserFacingException(L.T("Steam API вернул неожиданный ответ.", "Steam API returned an unexpected response."));
            }

            if (result.Count == 0)
                throw new UserFacingException(L.T("Steam не вернул статистику DBD для этого игрока.", "Steam returned no DBD stats for this player."));

            return result;
        }
    }
}
