using System.Collections.ObjectModel;
using System.Text.RegularExpressions;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using DbdTracker.App.Localization;
using DbdTracker.App.Models;
using DbdTracker.App.Services;
using Microsoft.UI.Xaml.Media;

namespace DbdTracker.App.ViewModels;

public sealed class RecentPlayerViewModel(RecentPlayer player)
{
    public string SteamId { get; } = player.SteamId;
    public string Name { get; } = player.Name;
    public ImageSource? Avatar { get; } = ProfileViewModel.TryImage(player.AvatarUrl, 48);
}

public sealed partial class MiniViewModel : ObservableObject
{
    private CancellationTokenSource? _cts;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(SearchCommand))]
    private string _query = "";

    [ObservableProperty] private bool _isLoading;
    [ObservableProperty] private bool _hasError;
    [ObservableProperty] private string _errorMessage = "";

    [ObservableProperty] private bool _hasProfile;
    [ObservableProperty] private bool _showEmptyState = true;
    [ObservableProperty] private string _steamId = "";
    [ObservableProperty] private string _name = "";
    [ObservableProperty] private ImageSource? _avatar;
    [ObservableProperty] private string _statusText = "";
    [ObservableProperty] private string _hoursText = "";
    [ObservableProperty] private string _profileUrl = "";

    [ObservableProperty] private string _bansText = "";
    [ObservableProperty] private bool _hasBanWarning;
    [ObservableProperty] private bool _hasBansClean;

    [ObservableProperty] private bool _hasNewbieFlag;
    [ObservableProperty] private string _newbieFlag = "";

    [ObservableProperty] private bool _hasNote;
    [ObservableProperty] private string _note = "";

    [ObservableProperty] private bool _hasRecent;

    public ObservableCollection<StatCardViewModel> Highlights { get; } = [];

    public ObservableCollection<StatCardViewModel> Stats { get; } = [];
    public ObservableCollection<RecentPlayerViewModel> Recent { get; } = [];

    public MiniViewModel()
    {
        RefreshRecent();
    }

    public static bool LooksLikeSteam(string? text)
    {
        if (string.IsNullOrWhiteSpace(text)) return false;
        text = text.Trim();
        return text.Contains("steamcommunity.com/", StringComparison.OrdinalIgnoreCase) ||
               Regex.IsMatch(text, @"^7656\d{13}$");
    }

    private bool CanSearch() => !string.IsNullOrWhiteSpace(Query);

    [RelayCommand(CanExecute = nameof(CanSearch))]
    private async Task SearchAsync()
    {
        await RunAsync(async ct =>
        {
            var id = await AppServices.Players.ResolveAsync(Query, ct);
            await LoadCoreAsync(id, refresh: false, ct);
        });
    }

    [RelayCommand]
    private Task RefreshAsync() =>
        string.IsNullOrEmpty(SteamId) ? Task.CompletedTask : RunAsync(ct => LoadCoreAsync(SteamId, refresh: true, ct));

    public Task OpenRecentAsync(string steamId) => RunAsync(ct => LoadCoreAsync(steamId, refresh: false, ct));

    public void ClearRecent()
    {
        AppServices.Recent.Clear();
        RefreshRecent();
    }

    private async Task RunAsync(Func<CancellationToken, Task> action)
    {
        _cts?.Cancel();
        var cts = _cts = new CancellationTokenSource();

        IsLoading = true;
        HasError = false;
        try
        {
            await action(cts.Token);
        }
        catch (OperationCanceledException) when (cts.IsCancellationRequested)
        {
        }
        catch (UserFacingException ex)
        {
            ErrorMessage = ex.Message;
            HasError = true;
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException)
        {
            ErrorMessage = L.T("Нет соединения со Steam. Проверь интернет.", "No connection to Steam. Check your internet connection.");
            HasError = true;
        }
        catch (Exception ex)
        {
            App.Log(ex);
            ErrorMessage = $"{ex.GetType().Name}: {ex.Message}";
            HasError = true;
        }
        finally
        {
            if (ReferenceEquals(_cts, cts)) IsLoading = false;
        }
    }

    private async Task LoadCoreAsync(string steamId, bool refresh, CancellationToken ct)
    {
        var p = await AppServices.Players.GetProfileAsync(steamId, refresh, ct);
        ct.ThrowIfCancellationRequested();
        Apply(p);

        AppServices.Recent.Add(new RecentPlayer(p.Summary.SteamId, p.Summary.Name, p.Summary.AvatarUrl));
        RefreshRecent();
    }

    private PlayerProfile? _last;

    public void Reapply()
    {
        if (_last is not null) BuildCards(_last);
    }

    private void BuildCards(PlayerProfile p)
    {
        Highlights.Clear();
        Stats.Clear();

        var available = CollectCards(p);
        var shown = 0;
        foreach (var key in AppServices.Settings.EffectiveMiniStats)
        {
            if (!available.TryGetValue(key, out var card)) continue;
            (shown++ < MiniStatOptions.BigCards ? Highlights : Stats).Add(card);
        }
    }

    private static Dictionary<string, StatCardViewModel> CollectCards(PlayerProfile p)
    {
        var cards = new Dictionary<string, StatCardViewModel>();

        if (p.RawStats is { } raw)
        {
            if (raw.TryGetValue(PlayerInsights.SurvivorPipsKey, out var sp))
            {
                var (g, pr) = PlayerInsights.GradeFromPips(sp);
                cards[MiniStatOptions.GradeSurvivor] = new StatCardViewModel(L.T("Ранг выжившего", "Survivor grade"), g, pr);
            }
            foreach (var k in PlayerInsights.KillerPipsKeys)
            {
                if (!raw.TryGetValue(k, out var kp)) continue;
                var (g, pr) = PlayerInsights.GradeFromPips(kp);
                cards[MiniStatOptions.GradeKiller] = new StatCardViewModel(L.T("Ранг убийцы", "Killer grade"), g, pr);
                break;
            }
        }

        var fromHistory = p.DetailedStats is null && p.LastKnownStats is not null;
        var caption = fromHistory && p.LastKnownDate is { } d
            ? L.T("на ", "as of ") + d.ToString(L.IsEnglish ? "MMM d" : "d MMM", L.Culture)
            : "";
        foreach (var st in (p.DetailedStats ?? p.LastKnownStats ?? Array.Empty<StatGroup>()).SelectMany(g => g.Stats))
            cards.TryAdd(st.Key, new StatCardViewModel(st.Label, L.FormatNumber(st.Value), caption));

        if (p.Stats is { Achievements.Count: > 0 } stats)
        {
            var all = stats.Achievements;
            var unlocked = all.Count(a => a.Unlocked);
            cards[MiniStatOptions.Achievements] = new StatCardViewModel(
                L.SectionAchievements,
                $"{unlocked} / {all.Count}",
                (100.0 * unlocked / all.Count).ToString("N0", L.Culture) + "%");

            var adepts = all.Where(a => a.Name.StartsWith("Adept ", StringComparison.OrdinalIgnoreCase)).ToList();
            var killers = adepts.Where(ProfileViewModel.IsKillerAdept).ToList();
            var survivors = adepts.Except(killers).ToList();

            cards[MiniStatOptions.AdeptsSurvivor] = new StatCardViewModel(
                L.T("Адепты выживших", "Survivor adepts"), $"{survivors.Count(a => a.Unlocked)} / {survivors.Count}");
            cards[MiniStatOptions.AdeptsKiller] = new StatCardViewModel(
                L.T("Адепты убийц", "Killer adepts"), $"{killers.Count(a => a.Unlocked)} / {killers.Count}");
        }

        return cards;
    }

    private void Apply(PlayerProfile p)
    {
        _last = p;
        var s = p.Summary;
        SteamId = s.SteamId;
        Name = s.Name;
        Avatar = ProfileViewModel.TryImage(s.AvatarUrl, 128);
        ProfileUrl = s.ProfileUrl;
        StatusText = ProfileViewModel.OnlineText(s.OnlineState) + (s.IsPublic ? "" : L.ProfilePrivate);
        HoursText = PlayerInsights.HoursText(p, shortForm: true);

        NewbieFlag = PlayerInsights.NewbieFlag(p) ?? "";
        HasNewbieFlag = NewbieFlag.Length > 0;

        BansText = PlayerInsights.BansText(p.Bans) ?? "";
        HasBanWarning = p.Bans?.HasAny == true;
        HasBansClean = p.Bans is { HasAny: false };

        BuildCards(p);

        string? problem = (p.StatsError ?? p.DetailedError) is { } err
            ? err + (p.LastKnownDate is { } kd && p.DetailedStats is null ? " " + PlayerInsights.LastKnownNote(kd) : "")
            : null;
        Note = problem
               ?? (AppServices.Keys.HasKey ? "" : L.T(
                   "Ранги, побеги и генераторы появятся после добавления ключа Steam API в Настройках.",
                   "Grades, escapes and generators appear after adding a Steam API key in Settings."));
        HasNote = Note.Length > 0;

        HasProfile = true;
        ShowEmptyState = false;
    }

    private void RefreshRecent()
    {
        Recent.Clear();
        foreach (var r in AppServices.Recent.Items)
            Recent.Add(new RecentPlayerViewModel(r));
        HasRecent = Recent.Count > 0;
    }
}
