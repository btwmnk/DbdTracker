using DbdTracker.App.Localization;
using System.Net;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using DbdTracker.App.Models;

namespace DbdTracker.App.Services;

public sealed partial class SteamCommunityClient(HttpClient http)
{
    private const string Base = "https://steamcommunity.com";

    public async Task<string> ResolveAsync(string input, CancellationToken ct = default)
    {
        input = input.Trim().TrimEnd('/');
        if (input.Length == 0) throw new UserFacingException(L.T("Вставь ссылку на профиль.", "Paste a profile link."));

        if (SteamId64().IsMatch(input)) return input;

        var candidate = input.StartsWith("steamcommunity.com", StringComparison.OrdinalIgnoreCase)
            ? "https://" + input
            : input;

        string? vanity = null;
        if (Uri.TryCreate(candidate, UriKind.Absolute, out var uri))
        {
            if (!uri.Host.EndsWith("steamcommunity.com", StringComparison.OrdinalIgnoreCase))
                throw new UserFacingException(L.T("Это не ссылка на профиль Steam.", "This is not a Steam profile link."));

            var parts = uri.AbsolutePath.Trim('/').Split('/', StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length >= 2 && parts[0] == "profiles" && SteamId64().IsMatch(parts[1])) return parts[1];
            if (parts.Length >= 2 && parts[0] == "id") vanity = parts[1];
        }
        else if (Vanity().IsMatch(input))
        {
            vanity = input;
        }

        if (vanity is null) throw new UserFacingException(L.T("Не понял ссылку. Пример: https://steamcommunity.com/id/ник", "Couldn't read the link. Example: https://steamcommunity.com/id/name"));

        var xml = await GetXmlAsync($"{Base}/id/{Uri.EscapeDataString(vanity)}/?xml=1", ct);
        return xml.Root?.Element("steamID64")?.Value.Trim()
               ?? throw new UserFacingException(L.T("Игрок с такой ссылкой не найден.", "No player found for this link."));
    }

    public async Task<PlayerSummary> GetSummaryAsync(string steamId, CancellationToken ct = default)
    {
        var xml = await GetXmlAsync($"{Base}/profiles/{steamId}/?xml=1", ct);
        var p = xml.Root ?? throw new UserFacingException(L.T("Профиль не найден.", "Profile not found."));

        return new PlayerSummary(
            SteamId: steamId,
            Name: p.Element("steamID")?.Value.Trim() ?? steamId,
            AvatarUrl: p.Element("avatarFull")?.Value.Trim() ?? "",
            ProfileUrl: $"{Base}/profiles/{steamId}",
            OnlineState: p.Element("onlineState")?.Value.Trim() ?? "",
            IsPublic: p.Element("privacyState")?.Value.Trim() == "public",
            MemberSince: ParseMemberSince(p.Element("memberSince")?.Value),
            DbdHoursOnRecord: DbdMostPlayed(p, "hoursOnRecord"),
            DbdHoursRecent: DbdMostPlayed(p, "hoursPlayed"));
    }

    private static double? DbdMostPlayed(System.Xml.Linq.XElement profile, string field)
    {
        var game = profile.Element("mostPlayedGames")?.Elements("mostPlayedGame")
            .FirstOrDefault(g => (g.Element("gameLink")?.Value ?? "").Contains($"/app/{AppConfig.DbdAppId}"));
        return ParseHours(game?.Element(field)?.Value);
    }

    internal static double? ParseHours(string? text)
    {
        if (string.IsNullOrWhiteSpace(text)) return null;
        var clean = text.Trim().Replace(",", "").Replace("\u00A0", "").Replace(" ", "");
        return double.TryParse(clean, System.Globalization.NumberStyles.Float,
            System.Globalization.CultureInfo.InvariantCulture, out var v) ? v : null;
    }

    private static DateOnly? ParseMemberSince(string? text)
    {
        if (string.IsNullOrWhiteSpace(text)) return null;
        text = text.Trim();
        var inv = System.Globalization.CultureInfo.InvariantCulture;
        string[] formats = ["MMMM d, yyyy", "MMMM dd, yyyy", "MMM d, yyyy", "d MMMM, yyyy", "d MMMM yyyy", "MMMM d"];
        return DateTime.TryParseExact(text, formats, inv, System.Globalization.DateTimeStyles.AllowWhiteSpaces, out var dt)
            ? DateOnly.FromDateTime(dt)
            : null;
    }

    public async Task<GameStats> GetDbdStatsAsync(string steamId, CancellationToken ct = default)
    {
        XDocument xml;
        try
        {
            xml = await GetXmlAsync($"{Base}/profiles/{steamId}/stats/{AppConfig.DbdAppId}/?xml=1", ct);
        }
        catch (UserFacingException)
        {
            throw new UserFacingException(
                L.T("Steam не отдал статистику DBD. Скорее всего, у игрока закрыты «Сведения об играх» или он не играл в DBD.", "Steam didn't return DBD stats. The player's \"Game details\" are probably private, or they never played DBD."));
        }

        var root = xml.Root;
        if (root is null || root.Name != "playerstats" || root.Element("error") is not null)
            throw new UserFacingException(
                L.T("Игрок скрыл «Сведения об играх» в Steam — эту статистику не видит ни одна программа или сайт. Открыть её может только сам игрок (Профиль → Приватность).", "The player hides \"Game details\" on Steam — no app or website can see these stats. Only the player can make them public (Profile → Privacy)."));

        var hours = ParseHours(root.Element("stats")?.Element("hoursPlayed")?.Value);

        var achievements = root.Element("achievements")?.Elements("achievement")
            .Select(a =>
            {
                var unlocked = a.Attribute("closed")?.Value == "1";
                DateTimeOffset? at = long.TryParse(a.Element("unlockTimestamp")?.Value, out var ts) && ts > 0
                    ? DateTimeOffset.FromUnixTimeSeconds(ts)
                    : null;
                return new Achievement(
                    ApiName: a.Element("apiname")?.Value.Trim() ?? "",
                    Name: a.Element("name")?.Value.Trim() ?? "",
                    Description: a.Element("description")?.Value.Trim() ?? "",

                    IconUrl: (unlocked ? a.Element("iconClosed") : a.Element("iconOpen"))?.Value.Trim() ?? "",
                    Unlocked: unlocked,
                    UnlockedAt: unlocked ? at : null);
            })
            .ToList() ?? [];

        return new GameStats(hours, achievements);
    }

    private async Task<XDocument> GetXmlAsync(string url, CancellationToken ct)
    {
        HttpResponseMessage resp;
        try
        {
            resp = await http.GetAsync(url, ct);
        }
        catch (HttpRequestException)
        {
            throw new UserFacingException(L.T("Steam недоступен. Проверь интернет.", "Steam is unreachable. Check your internet connection."));
        }

        using (resp)
        {
            if (resp.StatusCode == HttpStatusCode.TooManyRequests)
                throw new UserFacingException(L.T("Steam просит подождать: слишком много запросов. Попробуй через минуту.", "Steam is rate-limiting requests. Try again in a minute."));
            if (!resp.IsSuccessStatusCode)
                throw new UserFacingException(L.T("Steam вернул ошибку", "Steam returned an error") + $" ({(int)resp.StatusCode}).");

            XDocument doc;
            try
            {
                doc = XDocument.Parse(await resp.Content.ReadAsStringAsync(ct));
            }
            catch (System.Xml.XmlException)
            {
                throw new UserFacingException(L.T("Steam вернул неожиданный ответ. Попробуй ещё раз.", "Steam returned an unexpected response. Please try again."));
            }

            if (doc.Root?.Name == "response" && doc.Root.Element("error") is { } err)
                throw new UserFacingException(L.T("Профиль не найден: ", "Profile not found: ") + err.Value);

            return doc;
        }
    }

    [GeneratedRegex(@"^7656\d{13}$")]
    private static partial Regex SteamId64();

    [GeneratedRegex(@"^[A-Za-z0-9_-]{2,32}$")]
    private static partial Regex Vanity();
}
