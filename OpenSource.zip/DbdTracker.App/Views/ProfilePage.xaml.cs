using System.Diagnostics;
using DbdTracker.App.ViewModels;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Navigation;

namespace DbdTracker.App.Views;

public sealed partial class ProfilePage : Page
{
    public ProfileViewModel ViewModel { get; } = new();

    public string? SteamId { get; private set; }

    public ProfilePage()
    {
        InitializeComponent();
    }

    protected override async void OnNavigatedTo(NavigationEventArgs e)
    {
        base.OnNavigatedTo(e);
        SteamId = e.Parameter as string;
        if (SteamId is not null)
            await ViewModel.LoadAsync(SteamId);
    }

    private void OpenSteam_Click(object sender, RoutedEventArgs e) => Open(ViewModel.ProfileUrl);

    private void OpenAchievements_Click(object sender, RoutedEventArgs e) => Open(ViewModel.AchievementsUrl);

    private void OpenSettings_Click(object sender, RoutedEventArgs e) => Frame.Navigate(typeof(SettingsPage));

    private static void Open(string url)
    {
        if (!string.IsNullOrEmpty(url))
            Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
    }
}
