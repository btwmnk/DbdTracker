namespace DbdTracker.App;

public static class AppConfig
{
    public const int DbdAppId = 381210;

    public const string UserAgent = "DbdTracker-WinUI/1.0";

    public static string IconPath { get; } = Path.Combine(AppContext.BaseDirectory, "Assets", "app.ico");

    public static string DataFolder { get; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "DbdTracker");
}
