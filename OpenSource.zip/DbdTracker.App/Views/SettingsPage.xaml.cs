using System.Diagnostics;
using System.Text.RegularExpressions;
using DbdTracker.App.Localization;
using DbdTracker.App.Models;
using DbdTracker.App.Services;
using DbdTracker.App.ViewModels;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;

namespace DbdTracker.App.Views;

public sealed partial class SettingsPage : Page
{
    private bool _ready;

    public SettingsPage()
    {
        InitializeComponent();

        LanguageBox.SelectedIndex = L.IsEnglish ? 1 : 0;

        var st = AppServices.Settings;
        CloseToTraySwitch.IsOn = st.CloseToTray;
        HotkeySwitch.IsOn = st.HotkeyEnabled;
        AutoPasteSwitch.IsOn = st.AutoPaste;
        AutostartSwitch.IsOn = Autostart.IsEnabled;

        _ready = true;

        BuildMiniStats();

        UpdateStatus();
    }

    private void Language_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (!_ready || LanguageBox.SelectedItem is not ComboBoxItem { Tag: string lang } || lang == L.Language)
            return;

        L.SetLanguage(lang);

        DispatcherQueue.TryEnqueue(() => App.MainWindow?.ReloadUi());
    }

    private void CloseToTray_Toggled(object sender, RoutedEventArgs e)
    {
        if (!_ready) return;
        AppServices.Settings.CloseToTray = CloseToTraySwitch.IsOn;
        AppServices.Settings.Save();
    }

    private void Hotkey_Toggled(object sender, RoutedEventArgs e)
    {
        if (!_ready) return;
        AppServices.Settings.HotkeyEnabled = HotkeySwitch.IsOn;
        AppServices.Settings.Save();

        var ok = App.MainWindow?.ApplyHotkey() ?? true;
        HotkeyBusyText.Visibility = HotkeySwitch.IsOn && !ok ? Visibility.Visible : Visibility.Collapsed;
    }

    private void AutoPaste_Toggled(object sender, RoutedEventArgs e)
    {
        if (!_ready) return;
        AppServices.Settings.AutoPaste = AutoPasteSwitch.IsOn;
        AppServices.Settings.Save();
    }

    private void Autostart_Toggled(object sender, RoutedEventArgs e)
    {
        if (!_ready) return;
        try
        {
            Autostart.Set(AutostartSwitch.IsOn);
        }
        catch (Exception ex)
        {
            App.Log(ex);
            _ready = false;
            AutostartSwitch.IsOn = Autostart.IsEnabled;
            _ready = true;
            Show(InfoBarSeverity.Error, L.Error, ex.Message);
        }
    }

    private List<string> MiniSelection =>
        AppServices.Settings.MiniStats ??= [.. MiniStatOptions.Defaults()];

    private void SaveMiniSelection()
    {
        AppServices.Settings.Save();
        BuildMiniStats();
    }

    private void BuildMiniStats()
    {
        var options = MiniStatOptions.All().ToList();
        var labels = options.ToDictionary(o => o.Key, o => o.Label);
        var selected = MiniSelection;

        MiniSelectedPanel.Children.Clear();
        if (selected.Count == 0)
            MiniSelectedPanel.Children.Add(new TextBlock { Text = L.MiniStatsEmpty, Opacity = 0.6, FontSize = 12 });

        for (var i = 0; i < selected.Count; i++)
        {
            var key = selected[i];
            if (!labels.TryGetValue(key, out var label)) continue;

            var row = new Grid { ColumnSpacing = 6, Padding = new Thickness(8, 4, 4, 4), CornerRadius = new CornerRadius(4) };
            if (i < MiniStatOptions.BigCards &&
                Application.Current.Resources.TryGetValue("SubtleFillColorSecondaryBrush", out var bg) &&
                bg is Microsoft.UI.Xaml.Media.Brush brush)
                row.Background = brush;
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(28) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            row.Children.Add(new TextBlock { Text = $"{i + 1}.", Opacity = 0.6, VerticalAlignment = VerticalAlignment.Center });

            var name = new TextBlock { Text = label, VerticalAlignment = VerticalAlignment.Center, TextTrimming = TextTrimming.CharacterEllipsis };
            if (i < MiniStatOptions.BigCards) name.FontWeight = Microsoft.UI.Text.FontWeights.SemiBold;
            Grid.SetColumn(name, 1);
            row.Children.Add(name);

            var index = i;
            row.Children.Add(IconButton("\uE70E", L.MoveUp, 2, index > 0, () => Move(index, -1)));
            row.Children.Add(IconButton("\uE70D", L.MoveDown, 3, index < selected.Count - 1, () => Move(index, +1)));
            row.Children.Add(IconButton("\uE711", L.Remove, 4, true, () =>
            {
                selected.RemoveAt(index);
                SaveMiniSelection();
            }));

            MiniSelectedPanel.Children.Add(row);
        }

        MiniAllPanel.Children.Clear();
        foreach (var group in options.GroupBy(o => o.GroupTitle))
        {
            MiniAllPanel.Children.Add(new TextBlock
            {
                Text = group.Key,
                FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
                Margin = new Thickness(0, 4, 0, 0),
            });

            var grid = new DbdTracker.App.Controls.UniformWrapPanel { MinItemWidth = 260, ColumnSpacing = 8, RowSpacing = 0 };
            foreach (var (key, label, _) in group)
            {
                var box = new CheckBox { Content = label, IsChecked = selected.Contains(key), Tag = key };
                box.Checked += (_, _) =>
                {
                    if (!selected.Contains(key)) selected.Add(key);
                    SaveMiniSelection();
                };
                box.Unchecked += (_, _) =>
                {
                    selected.Remove(key);
                    SaveMiniSelection();
                };
                grid.Children.Add(box);
            }
            MiniAllPanel.Children.Add(grid);
        }
    }

    private void Move(int index, int delta)
    {
        var list = MiniSelection;
        var target = index + delta;
        if (target < 0 || target >= list.Count) return;
        (list[index], list[target]) = (list[target], list[index]);
        SaveMiniSelection();
    }

    private static Button IconButton(string glyph, string tooltip, int column, bool enabled, Action onClick)
    {
        var b = new Button
        {
            Content = new FontIcon { Glyph = glyph, FontSize = 12 },
            Padding = new Thickness(8, 6, 8, 6),
            IsEnabled = enabled,
        };
        ToolTipService.SetToolTip(b, tooltip);
        b.Click += (_, _) => onClick();
        Grid.SetColumn(b, column);
        return b;
    }

    private void MiniStatsReset_Click(object sender, RoutedEventArgs e)
    {
        AppServices.Settings.MiniStats = MiniStatOptions.Defaults();
        SaveMiniSelection();
    }

    private void UpdateStatus()
    {
        var has = AppServices.Keys.HasKey;
        StatusText.Text = has ? L.KeySaved : L.KeyNotSet;
        RemoveButton.IsEnabled = has;
    }

    private async void Save_Click(object sender, RoutedEventArgs e)
    {
        var key = KeyBox.Password.Trim();
        ResultBar.IsOpen = false;

        if (!Regex.IsMatch(key, "^[A-Fa-f0-9]{32}$"))
        {
            Show(InfoBarSeverity.Warning,
                L.T("Не похоже на ключ", "That doesn't look like a key"),
                L.T("Ключ Steam — это 32 символа из цифр и букв A–F.", "A Steam key is 32 characters: digits and letters A–F."));
            return;
        }

        SaveButton.IsEnabled = false;
        Busy.IsActive = true;
        try
        {
            if (await AppServices.WebApi.ValidateKeyAsync(key))
            {
                AppServices.Keys.Save(key);
                KeyBox.Password = "";
                Show(InfoBarSeverity.Success,
                    L.T("Готово", "Done"),
                    L.T("Ключ работает. Открой профиль — там появятся точные цифры.", "The key works. Open a profile to see exact numbers."));
            }
            else
            {
                Show(InfoBarSeverity.Error,
                    L.T("Steam не принял ключ", "Steam rejected the key"),
                    L.T("Проверь, что скопировал его целиком.", "Make sure you copied the whole key."));
            }
        }
        catch (UserFacingException ex)
        {
            Show(InfoBarSeverity.Error, L.Error, ex.Message);
        }
        catch (Exception ex)
        {
            App.Log(ex);
            Show(InfoBarSeverity.Error, L.Error, ex.Message);
        }
        finally
        {
            SaveButton.IsEnabled = true;
            Busy.IsActive = false;
            UpdateStatus();
        }
    }

    private void Remove_Click(object sender, RoutedEventArgs e)
    {
        AppServices.Keys.Clear();
        Show(InfoBarSeverity.Informational,
            L.T("Ключ удалён", "Key removed"),
            L.T("Теперь показываются только часы и достижения.", "Only hours and achievements are shown now."));
        UpdateStatus();
    }

    private void OpenKeyPage_Click(object sender, RoutedEventArgs e) =>
        Process.Start(new ProcessStartInfo("https://steamcommunity.com/dev/apikey") { UseShellExecute = true });

    private void OpenLog_Click(object sender, RoutedEventArgs e)
    {
        if (File.Exists(App.CrashLogPath))
            Process.Start(new ProcessStartInfo(App.CrashLogPath) { UseShellExecute = true });
        else
            Show(InfoBarSeverity.Success, L.T("Журнал пуст", "Log is empty"), L.T("Ошибок пока не было.", "No errors so far."));
    }

    private void Show(InfoBarSeverity severity, string title, string message)
    {
        ResultBar.Severity = severity;
        ResultBar.Title = title;
        ResultBar.Message = message;
        ResultBar.IsOpen = true;
    }
}
