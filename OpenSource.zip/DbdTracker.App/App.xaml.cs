using DbdTracker.App.Localization;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.Windows.AppLifecycle;
using Windows.ApplicationModel.Activation;

namespace DbdTracker.App;

public partial class App : Application
{
    public static MainWindow? MainWindow { get; private set; }

    public static string CrashLogPath { get; } = Path.Combine(AppConfig.DataFolder, "crash.log");

    public App()
    {
        InitializeComponent();

        UnhandledException += OnUnhandledException;
        TaskScheduler.UnobservedTaskException += (_, e) =>
        {
            Log(e.Exception);
            e.SetObserved();
        };
    }

    protected override void OnLaunched(Microsoft.UI.Xaml.LaunchActivatedEventArgs args)
    {
        var cmd = Environment.GetCommandLineArgs();
        MainWindow = new MainWindow();

        if (cmd.Contains("--tray", StringComparer.OrdinalIgnoreCase))
        {
        }
        else if (cmd.Contains("--mini", StringComparer.OrdinalIgnoreCase))
        {
            MainWindow.ShowMini();
        }
        else
        {
            MainWindow.ShowMain();
        }
    }

    public static void OnRedirectedActivation(AppActivationArguments args)
    {
        var mini = args.Kind == ExtendedActivationKind.Launch &&
                   args.Data is ILaunchActivatedEventArgs launch &&
                   (launch.Arguments ?? "").Contains("--mini", StringComparison.OrdinalIgnoreCase);

        MainWindow?.DispatcherQueue.TryEnqueue(() =>
        {
            if (mini) MainWindow.ShowMini();
            else MainWindow.ShowMain();
        });
    }

    private async void OnUnhandledException(object sender, Microsoft.UI.Xaml.UnhandledExceptionEventArgs e)
    {
        e.Handled = true;
        Log(e.Exception);

        try
        {
            if (MainWindow?.Content?.XamlRoot is { } root && MainWindow.AppWindow.IsVisible)
            {
                var dialog = new ContentDialog
                {
                    XamlRoot = root,
                    Title = L.T("Что-то пошло не так", "Something went wrong"),
                    Content = new ScrollViewer
                    {
                        MaxHeight = 360,
                        Content = new TextBlock
                        {
                            Text = $"{e.Exception.GetType().Name}: {e.Exception.Message}\n\n{L.T("Подробности сохранены в:", "Details saved to:")}\n{CrashLogPath}",
                            TextWrapping = TextWrapping.Wrap,
                            IsTextSelectionEnabled = true,
                        },
                    },
                    CloseButtonText = "OK",
                };
                await dialog.ShowAsync();
            }
        }
        catch
        {
        }
    }

    public static void Log(Exception ex)
    {
        try
        {
            Directory.CreateDirectory(AppConfig.DataFolder);
            File.AppendAllText(CrashLogPath, $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {ex}\n\n");
        }
        catch
        {
        }
    }
}
