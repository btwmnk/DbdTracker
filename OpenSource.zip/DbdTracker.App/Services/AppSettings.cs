using System.Text.Json;
using Microsoft.Win32;

namespace DbdTracker.App.Services;

public sealed class AppSettings
{
    private static readonly string FilePath = Path.Combine(AppConfig.DataFolder, "settings.json");

    public bool CloseToTray { get; set; } = true;

    public bool HotkeyEnabled { get; set; } = true;

    public bool AutoPaste { get; set; } = true;

    public List<string>? MiniStats { get; set; }

    [System.Text.Json.Serialization.JsonIgnore]
    public IReadOnlyList<string> EffectiveMiniStats => MiniStats ?? ViewModels.MiniStatOptions.Defaults();

    public bool TrayHintShown { get; set; }

    public static AppSettings Load()
    {
        try
        {
            if (File.Exists(FilePath))
                return JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(FilePath)) ?? new AppSettings();
        }
        catch (Exception ex) when (ex is IOException or JsonException or UnauthorizedAccessException)
        {
        }
        return new AppSettings();
    }

    public void Save()
    {
        try
        {
            Directory.CreateDirectory(AppConfig.DataFolder);
            File.WriteAllText(FilePath, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
        }
    }
}

public static class Autostart
{
    private const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
    private const string ValueName = "DbdTracker";

    private static string Command => $"\"{Environment.ProcessPath}\" --tray";

    public static bool IsEnabled
    {
        get
        {
            try
            {
                using var key = Registry.CurrentUser.OpenSubKey(RunKey);
                return key?.GetValue(ValueName) is string;
            }
            catch
            {
                return false;
            }
        }
    }

    public static void Set(bool enabled)
    {
        using var key = Registry.CurrentUser.CreateSubKey(RunKey);
        if (enabled) key.SetValue(ValueName, Command);
        else key.DeleteValue(ValueName, throwOnMissingValue: false);
    }
}
