using System.Runtime.InteropServices;
using Microsoft.UI.Dispatching;

namespace DbdTracker.App.Services;

public sealed class TrayService : IDisposable
{
    public sealed record MenuItem(int Id, string Text, bool IsSeparator = false, bool IsDefault = false);

    public event Action? Clicked;

    public event Action<int>? MenuItemSelected;

    public event Action? HotkeyPressed;

    public Func<IReadOnlyList<MenuItem>>? MenuProvider { get; set; }

    private const uint TrayIconId = 1;
    private const int HotkeyId = 0xD0D;

    private readonly IntPtr _hwnd;
    private readonly DispatcherQueue _dispatcher;
    private readonly SubclassProc _proc;
    private readonly uint _callbackMessage;
    private readonly uint _taskbarCreatedMessage;
    private readonly IntPtr _icon;
    private string _tooltip;
    private bool _added;
    private bool _hotkeyRegistered;
    private bool _disposed;

    public TrayService(IntPtr hwnd, string iconPath, string tooltip)
    {
        _hwnd = hwnd;
        _tooltip = tooltip;
        _dispatcher = DispatcherQueue.GetForCurrentThread();
        _callbackMessage = RegisterWindowMessageW("DbdTracker.TrayCallback");
        _taskbarCreatedMessage = RegisterWindowMessageW("TaskbarCreated");

        var cx = GetSystemMetrics(SM_CXSMICON);
        var cy = GetSystemMetrics(SM_CYSMICON);
        _icon = File.Exists(iconPath) ? LoadImageW(IntPtr.Zero, iconPath, IMAGE_ICON, cx, cy, LR_LOADFROMFILE) : IntPtr.Zero;

        _proc = WndProc;
        SetWindowSubclass(_hwnd, _proc, UIntPtr.Zero, UIntPtr.Zero);

        AddIcon();
    }

    public void SetTooltip(string tooltip)
    {
        _tooltip = tooltip;
        if (!_added) return;
        var data = CreateData(NIF_TIP);
        Shell_NotifyIconW(NIM_MODIFY, ref data);
    }

    public void ShowBalloon(string title, string text)
    {
        if (!_added) return;
        var data = CreateData(NIF_INFO);
        data.szInfoTitle = Truncate(title, 63);
        data.szInfo = Truncate(text, 255);
        data.dwInfoFlags = NIIF_INFO | NIIF_NOSOUND;
        Shell_NotifyIconW(NIM_MODIFY, ref data);
    }

    public bool SetHotkey(bool enabled)
    {
        if (_hotkeyRegistered)
        {
            UnregisterHotKey(_hwnd, HotkeyId);
            _hotkeyRegistered = false;
        }

        if (!enabled) return true;

        _hotkeyRegistered = RegisterHotKey(_hwnd, HotkeyId, MOD_CONTROL | MOD_SHIFT | MOD_NOREPEAT, VK_D);
        return _hotkeyRegistered;
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;

        SetHotkey(false);
        if (_added)
        {
            var data = CreateData(0);
            Shell_NotifyIconW(NIM_DELETE, ref data);
            _added = false;
        }
        RemoveWindowSubclass(_hwnd, _proc, UIntPtr.Zero);
        if (_icon != IntPtr.Zero) DestroyIcon(_icon);
    }

    private void AddIcon()
    {
        var data = CreateData(NIF_MESSAGE | NIF_ICON | NIF_TIP);
        _added = Shell_NotifyIconW(NIM_ADD, ref data);
    }

    private NOTIFYICONDATAW CreateData(uint flags) => new()
    {
        cbSize = (uint)Marshal.SizeOf<NOTIFYICONDATAW>(),
        hWnd = _hwnd,
        uID = TrayIconId,
        uFlags = flags,
        uCallbackMessage = _callbackMessage,
        hIcon = _icon,
        szTip = Truncate(_tooltip, 127),
        szInfo = "",
        szInfoTitle = "",
    };

    private IntPtr WndProc(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam, UIntPtr id, UIntPtr refData)
    {
        try
        {
            if (msg == _callbackMessage)
            {
                switch ((uint)lParam.ToInt64() & 0xFFFF)
                {
                    case WM_LBUTTONUP:
                    case NIN_BALLOONUSERCLICK:
                        _dispatcher.TryEnqueue(() => Clicked?.Invoke());
                        break;
                    case WM_RBUTTONUP:
                    case WM_CONTEXTMENU:
                        ShowMenu();
                        break;
                }
                return IntPtr.Zero;
            }

            if (msg == WM_HOTKEY && (long)wParam == HotkeyId)
            {
                _dispatcher.TryEnqueue(() => HotkeyPressed?.Invoke());
                return IntPtr.Zero;
            }

            if (msg == _taskbarCreatedMessage && !_disposed)
            {
                _added = false;
                AddIcon();
            }
        }
        catch (Exception ex)
        {
            App.Log(ex);
        }

        return DefSubclassProc(hWnd, msg, wParam, lParam);
    }

    private void ShowMenu()
    {
        var items = MenuProvider?.Invoke();
        if (items is null || items.Count == 0) return;

        var menu = CreatePopupMenu();
        try
        {
            foreach (var item in items)
            {
                if (item.IsSeparator) AppendMenuW(menu, MF_SEPARATOR, UIntPtr.Zero, null);
                else AppendMenuW(menu, MF_STRING, (nuint)item.Id, item.Text);
            }

            var def = items.FirstOrDefault(i => i.IsDefault);
            if (def is not null) SetMenuDefaultItem(menu, (uint)def.Id, 0);

            GetCursorPos(out var pt);

            SetForegroundWindow(_hwnd);
            var cmd = TrackPopupMenuEx(menu, TPM_RETURNCMD | TPM_RIGHTBUTTON | TPM_BOTTOMALIGN, pt.X, pt.Y, _hwnd, IntPtr.Zero);
            PostMessageW(_hwnd, WM_NULL, IntPtr.Zero, IntPtr.Zero);

            if (cmd != 0)
                _dispatcher.TryEnqueue(() => MenuItemSelected?.Invoke((int)cmd));
        }
        finally
        {
            DestroyMenu(menu);
        }
    }

    private static string Truncate(string s, int max) => s.Length <= max ? s : s[..max];

    private delegate IntPtr SubclassProc(IntPtr hWnd, uint uMsg, IntPtr wParam, IntPtr lParam, UIntPtr uIdSubclass, UIntPtr dwRefData);

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct NOTIFYICONDATAW
    {
        public uint cbSize;
        public IntPtr hWnd;
        public uint uID;
        public uint uFlags;
        public uint uCallbackMessage;
        public IntPtr hIcon;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string szTip;
        public uint dwState;
        public uint dwStateMask;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)] public string szInfo;
        public uint uVersionOrTimeout;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)] public string szInfoTitle;
        public uint dwInfoFlags;
        public Guid guidItem;
        public IntPtr hBalloonIcon;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct POINT
    {
        public int X;
        public int Y;
    }

    private const uint NIM_ADD = 0, NIM_MODIFY = 1, NIM_DELETE = 2;
    private const uint NIF_MESSAGE = 0x1, NIF_ICON = 0x2, NIF_TIP = 0x4, NIF_INFO = 0x10;
    private const uint NIIF_INFO = 0x1, NIIF_NOSOUND = 0x10;
    private const uint NIN_BALLOONUSERCLICK = 0x405;
    private const uint WM_NULL = 0x0, WM_CONTEXTMENU = 0x7B, WM_HOTKEY = 0x312, WM_LBUTTONUP = 0x202, WM_RBUTTONUP = 0x205;
    private const uint MF_STRING = 0x0, MF_SEPARATOR = 0x800;
    private const uint TPM_RIGHTBUTTON = 0x2, TPM_BOTTOMALIGN = 0x20, TPM_RETURNCMD = 0x100;
    private const uint IMAGE_ICON = 1, LR_LOADFROMFILE = 0x10;
    private const int SM_CXSMICON = 49, SM_CYSMICON = 50;
    private const uint MOD_CONTROL = 0x2, MOD_SHIFT = 0x4, MOD_NOREPEAT = 0x4000, VK_D = 0x44;

    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    private static extern bool Shell_NotifyIconW(uint dwMessage, ref NOTIFYICONDATAW lpData);

    [DllImport("comctl32.dll")]
    private static extern bool SetWindowSubclass(IntPtr hWnd, SubclassProc pfnSubclass, UIntPtr uIdSubclass, UIntPtr dwRefData);

    [DllImport("comctl32.dll")]
    private static extern bool RemoveWindowSubclass(IntPtr hWnd, SubclassProc pfnSubclass, UIntPtr uIdSubclass);

    [DllImport("comctl32.dll")]
    private static extern IntPtr DefSubclassProc(IntPtr hWnd, uint uMsg, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern uint RegisterWindowMessageW(string lpString);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr LoadImageW(IntPtr hInst, string name, uint type, int cx, int cy, uint fuLoad);

    [DllImport("user32.dll")]
    private static extern bool DestroyIcon(IntPtr hIcon);

    [DllImport("user32.dll")]
    private static extern int GetSystemMetrics(int nIndex);

    [DllImport("user32.dll")]
    private static extern IntPtr CreatePopupMenu();

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern bool AppendMenuW(IntPtr hMenu, uint uFlags, UIntPtr uIDNewItem, string? lpNewItem);

    [DllImport("user32.dll")]
    private static extern bool SetMenuDefaultItem(IntPtr hMenu, uint uItem, uint fByPos);

    [DllImport("user32.dll")]
    private static extern uint TrackPopupMenuEx(IntPtr hMenu, uint uFlags, int x, int y, IntPtr hWnd, IntPtr lptpm);

    [DllImport("user32.dll")]
    private static extern bool DestroyMenu(IntPtr hMenu);

    [DllImport("user32.dll")]
    private static extern bool GetCursorPos(out POINT lpPoint);

    [DllImport("user32.dll")]
    private static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool PostMessageW(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

    [DllImport("user32.dll")]
    private static extern bool UnregisterHotKey(IntPtr hWnd, int id);
}
