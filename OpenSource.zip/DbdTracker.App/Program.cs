using System.Diagnostics;
using System.Runtime.InteropServices;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml;
using Microsoft.Windows.AppLifecycle;

namespace DbdTracker.App;

public static class Program
{
    private const string InstanceKey = "DbdTracker.Main";

    [STAThread]
    private static int Main(string[] args)
    {
        try
        {
            WinRT.ComWrappersSupport.InitializeComWrappers();

            if (RedirectToRunningInstance())
                return 0;

            Application.Start(p =>
            {
                var context = new DispatcherQueueSynchronizationContext(DispatcherQueue.GetForCurrentThread());
                SynchronizationContext.SetSynchronizationContext(context);
                _ = new App();
            });

            return 0;
        }
        catch (Exception ex)
        {
            StartupFailed(ex);
            return 1;
        }
    }

    private static void StartupFailed(Exception ex)
    {
        var path = Path.Combine(AppConfig.DataFolder, "startup.log");
        try
        {
            Directory.CreateDirectory(AppConfig.DataFolder);
            File.AppendAllText(path,
                $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] exe={Environment.ProcessPath} base={AppContext.BaseDirectory}\n{ex}\n\n");
        }
        catch
        {
        }

        MessageBoxW(IntPtr.Zero,
            $"DBD Tracker failed to start:\n\n{ex.GetType().Name}: {ex.Message}\n\nLog: {path}",
            "DBD Tracker", 0x10);
    }

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int MessageBoxW(IntPtr hWnd, string text, string caption, uint type);

    private static bool RedirectToRunningInstance()
    {
        try
        {
            var activation = AppInstance.GetCurrent().GetActivatedEventArgs();
            var main = AppInstance.FindOrRegisterForKey(InstanceKey);

            if (main.IsCurrent)
            {
                main.Activated += (_, e) => App.OnRedirectedActivation(e);
                return false;
            }

            AllowSetForegroundWindow(main.ProcessId);

            var done = CreateEvent(IntPtr.Zero, true, false, null);
            Task.Run(() =>
            {
                main.RedirectActivationToAsync(activation).AsTask().Wait();
                SetEvent(done);
            });
            _ = CoWaitForMultipleObjects(0, 0xFFFFFFFF, 1, [done], out _);
            CloseHandle(done);
            return true;
        }
        catch (Exception ex)
        {
            Debug.WriteLine(ex);
            return false;
        }
    }

    [DllImport("user32.dll")]
    private static extern bool AllowSetForegroundWindow(uint dwProcessId);

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr CreateEvent(IntPtr lpEventAttributes, bool bManualReset, bool bInitialState, string? lpName);

    [DllImport("kernel32.dll")]
    private static extern bool SetEvent(IntPtr hEvent);

    [DllImport("kernel32.dll")]
    private static extern bool CloseHandle(IntPtr hObject);

    [DllImport("ole32.dll")]
    private static extern uint CoWaitForMultipleObjects(uint dwFlags, uint dwMilliseconds, uint nHandles, IntPtr[] pHandles, out uint dwIndex);
}
