using System.Security.Cryptography;
using System.Text;

namespace DbdTracker.App.Services;

public sealed class ApiKeyStore
{
    private static readonly byte[] Entropy = "DbdTracker.SteamKey.v1"u8.ToArray();
    private readonly string _path = Path.Combine(AppConfig.DataFolder, "steamkey.bin");

    public string? Key { get; private set; }

    public bool HasKey => !string.IsNullOrEmpty(Key);

    public event EventHandler? Changed;

    public ApiKeyStore()
    {
        try
        {
            if (File.Exists(_path))
                Key = Encoding.UTF8.GetString(
                    ProtectedData.Unprotect(File.ReadAllBytes(_path), Entropy, DataProtectionScope.CurrentUser));
        }
        catch (Exception ex) when (ex is CryptographicException or IOException)
        {
            Key = null;
        }
    }

    public void Save(string key)
    {
        key = key.Trim();
        Directory.CreateDirectory(AppConfig.DataFolder);
        File.WriteAllBytes(_path,
            ProtectedData.Protect(Encoding.UTF8.GetBytes(key), Entropy, DataProtectionScope.CurrentUser));
        Key = key;
        Changed?.Invoke(this, EventArgs.Empty);
    }

    public void Clear()
    {
        Key = null;
        try { File.Delete(_path); } catch (IOException) { }
        Changed?.Invoke(this, EventArgs.Empty);
    }
}
