using DbdTracker.App.Localization;
using DbdTracker.App.Services;
using DbdTracker.App.Views;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Media.Animation;

namespace DbdTracker.App;

public sealed partial class MainWindow : Window
{
    private const int MenuMini = 1, MenuOpen = 2, MenuExit = 3;

    private readonly TrayService? _tray;
    private MiniWindow? _mini;
    private bool _exiting;

    public MainWindow()
    {
        InitializeComponent();

        ExtendsContentIntoTitleBar = true;
        WindowHelper.StyleCaptionButtons(this);
        SetTitleBar(AppTitleBar);
        if (File.Exists(AppConfig.IconPath))
            AppWindow.SetIcon(AppConfig.IconPath);
        WindowHelper.ResizeLogical(this, 1500, 920);

        AppWindow.Closing += OnClosing;

        try
        {
            _tray = new TrayService(WindowHelper.Handle(this), AppConfig.IconPath, L.TrayTooltip);
            _tray.Clicked += ToggleMini;
            _tray.HotkeyPressed += ToggleMini;
            _tray.MenuProvider = () =>
            [
                new TrayService.MenuItem(MenuMini, L.TrayMini, IsDefault: true),
                new TrayService.MenuItem(MenuOpen, L.TrayOpen),
                new TrayService.MenuItem(0, "", IsSeparator: true),
                new TrayService.MenuItem(MenuExit, L.TrayExit),
            ];
            _tray.MenuItemSelected += id =>
            {
                switch (id)
                {
                    case MenuMini: ShowMini(); break;
                    case MenuOpen: ShowMain(); break;
                    case MenuExit: ExitApp(); break;
                }
            };
            ApplyHotkey();
        }
        catch (Exception ex)
        {
            App.Log(ex);
        }

        if (AppServices.Session.HasSession) ShowShell();
        else ShowLogin();
    }

    public void ShowMain() => WindowHelper.BringToFront(this);

    public void ShowMini()
    {
        _mini ??= new MiniWindow();
        _mini.ShowMini();
    }

    public void ToggleMini()
    {
        if (_mini is { IsShown: true }) _mini.Hide();
        else ShowMini();
    }

    public void SwitchToMini()
    {
        AppWindow.Hide();
        ShowMini();
    }

    public void OpenFromMini(string? steamId)
    {
        _mini?.Hide();

        if (steamId is not null)
        {
            if (RootFrame.Content is ShellPage { IsLoaded: true } shell)
            {
                shell.OpenProfile(steamId);
            }
            else
            {
                if (!AppServices.Session.HasSession) AppServices.Session.ContinueAsGuest();
                ShowShell("profile:" + steamId);
            }
        }

        ShowMain();
    }

    public void OpenSettingsFromMini()
    {
        _mini?.Hide();
        if (!AppServices.Session.HasSession) AppServices.Session.ContinueAsGuest();

        if (RootFrame.Content is ShellPage { IsLoaded: true } shell) shell.OpenSettings();
        else ShowShell("settings");

        ShowMain();
    }

    public bool ApplyHotkey() => _tray?.SetHotkey(AppServices.Settings.HotkeyEnabled) ?? false;

    private void OnClosing(Microsoft.UI.Windowing.AppWindow sender, Microsoft.UI.Windowing.AppWindowClosingEventArgs args)
    {
        if (_exiting) return;

        if (AppServices.Settings.CloseToTray && _tray is not null)
        {
            args.Cancel = true;
            AppWindow.Hide();

            if (!AppServices.Settings.TrayHintShown)
            {
                _tray.ShowBalloon(L.TrayBalloonTitle, L.TrayBalloonText);
                AppServices.Settings.TrayHintShown = true;
                AppServices.Settings.Save();
            }
            return;
        }

        args.Cancel = true;
        ExitApp();
    }

    public void ExitApp()
    {
        if (_exiting) return;
        _exiting = true;

        _tray?.Dispose();
        _mini?.ForceClose();
        _mini = null;
        Application.Current.Exit();
    }

    public void ShowLogin() => NavigateRoot(typeof(LoginPage), null);

    public void ShowShell(string? startPage = null) => NavigateRoot(typeof(ShellPage), startPage);

    public void ReloadUi()
    {
        AppServices.Players.ClearCache();
        _tray?.SetTooltip(L.TrayTooltip);

        _mini?.ForceClose();
        _mini = null;

        if (AppServices.Session.HasSession) ShowShell("settings");
        else ShowLogin();
    }

    public void SignOut()
    {
        AppServices.Session.SignOut();
        ShowLogin();
    }

    private void NavigateRoot(Type page, object? parameter)
    {
        RootFrame.Navigate(page, parameter, new DrillInNavigationTransitionInfo());
        RootFrame.BackStack.Clear();
    }
}
