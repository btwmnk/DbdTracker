using DbdTracker.App.Localization;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using DbdTracker.App.Models;

namespace DbdTracker.App.Services;

public sealed partial class AuthService(HttpClient http)
{
    private const string OpenIdEndpoint = "https://steamcommunity.com/openid/login";
    private static readonly TimeSpan LoginTimeout = TimeSpan.FromMinutes(5);

    public async Task<string> SignInAsync(CancellationToken ct)
    {
        var port = GetFreePort();
        var realm = $"http://localhost:{port}/";
        var returnTo = $"http://localhost:{port}/callback";

        using var listener = new HttpListener();
        listener.Prefixes.Add(realm);
        listener.Start();

        Process.Start(new ProcessStartInfo(BuildLoginUrl(returnTo, realm)) { UseShellExecute = true });

        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
        timeout.CancelAfter(LoginTimeout);
        using var reg = timeout.Token.Register(() => { try { listener.Stop(); } catch { } });

        while (true)
        {
            HttpListenerContext ctx;
            try
            {
                ctx = await listener.GetContextAsync();
            }
            catch (Exception) when (timeout.IsCancellationRequested)
            {
                throw new OperationCanceledException(L.T("Вход отменён или истекло время ожидания.", "Sign-in was cancelled or timed out."));
            }

            if (ctx.Request.Url?.AbsolutePath != "/callback")
            {
                ctx.Response.StatusCode = 404;
                ctx.Response.Close();
                continue;
            }

            string? steamId = null;
            try
            {
                steamId = await VerifyAsync(ctx.Request.QueryString, returnTo, timeout.Token);
            }
            finally
            {
                await WritePageAsync(ctx.Response, steamId is not null);
            }

            return steamId ?? throw new UserFacingException(L.T("Steam не подтвердил вход. Попробуй ещё раз.", "Steam did not confirm the sign-in. Please try again."));
        }
    }

    private static string BuildLoginUrl(string returnTo, string realm)
    {
        var p = new Dictionary<string, string>
        {
            ["openid.ns"] = "http://specs.openid.net/auth/2.0",
            ["openid.mode"] = "checkid_setup",
            ["openid.return_to"] = returnTo,
            ["openid.realm"] = realm,
            ["openid.identity"] = "http://specs.openid.net/auth/2.0/identifier_select",
            ["openid.claimed_id"] = "http://specs.openid.net/auth/2.0/identifier_select",
        };
        return OpenIdEndpoint + "?" + string.Join("&",
            p.Select(kv => $"{Uri.EscapeDataString(kv.Key)}={Uri.EscapeDataString(kv.Value)}"));
    }

    private async Task<string?> VerifyAsync(System.Collections.Specialized.NameValueCollection q, string returnTo, CancellationToken ct)
    {
        if (q["openid.mode"] != "id_res") return null;
        if (q["openid.op_endpoint"] != OpenIdEndpoint) return null;
        if (q["openid.return_to"]?.StartsWith(returnTo, StringComparison.Ordinal) != true) return null;

        var match = ClaimedId().Match(q["openid.claimed_id"] ?? "");
        if (!match.Success) return null;

        var form = q.AllKeys
            .Where(k => k is not null && k.StartsWith("openid.", StringComparison.Ordinal))
            .ToDictionary(k => k!, k => q[k] ?? "");
        form["openid.mode"] = "check_authentication";

        using var resp = await http.PostAsync(OpenIdEndpoint, new FormUrlEncodedContent(form), ct);
        var body = await resp.Content.ReadAsStringAsync(ct);
        return body.Split('\n').Any(l => l.Trim() == "is_valid:true") ? match.Groups[1].Value : null;
    }

    private static int GetFreePort()
    {
        var l = new TcpListener(IPAddress.Loopback, 0);
        l.Start();
        var port = ((IPEndPoint)l.LocalEndpoint).Port;
        l.Stop();
        return port;
    }

    private static async Task WritePageAsync(HttpListenerResponse resp, bool ok)
    {
        try
        {
            var title = ok ? L.T("Готово!", "Done!") : L.T("Не получилось", "Something went wrong");
            var text = ok ? L.T("Вход выполнен. Закрой эту вкладку и вернись в DBD Tracker.", "You are signed in. Close this tab and return to DBD Tracker.")
                          : L.T("Вход не удался. Вернись в приложение и попробуй ещё раз.", "Sign-in failed. Return to the app and try again.");
            var html = $$"""
                <!doctype html><html lang="{{L.Language}}"><head><meta charset="utf-8"><title>DBD Tracker</title>
                <style>body{font-family:Segoe UI,sans-serif;background:#141414;color:#eee;display:grid;place-items:center;height:100vh;margin:0}
                .c{text-align:center}h1{color:{{(ok ? "#e0b84f" : "#e05a4f")}}}</style></head>
                <body><div class="c"><h1>{{title}}</h1><p>{{text}}</p></div></body></html>
                """;
            var bytes = Encoding.UTF8.GetBytes(html);
            resp.ContentType = "text/html; charset=utf-8";
            resp.ContentLength64 = bytes.Length;
            await resp.OutputStream.WriteAsync(bytes);
        }
        finally
        {
            resp.Close();
        }
    }

    [GeneratedRegex(@"^https?://steamcommunity\.com/openid/id/(7656\d{13})$")]
    private static partial Regex ClaimedId();
}
