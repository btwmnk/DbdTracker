using System.Globalization;

namespace DbdTracker.App.Localization;

public static class L
{
    private static readonly string FilePath = Path.Combine(AppConfig.DataFolder, "language.txt");

    public static string Language { get; private set; } = LoadLanguage();

    public static bool IsEnglish => Language == "en";

    public static CultureInfo Culture => CultureInfo.GetCultureInfo(IsEnglish ? "en-US" : "ru-RU");

    public static void SetLanguage(string language)
    {
        Language = language == "en" ? "en" : "ru";
        try
        {
            Directory.CreateDirectory(AppConfig.DataFolder);
            File.WriteAllText(FilePath, Language);
        }
        catch (IOException) { }
    }

    private static string LoadLanguage()
    {
        try
        {
            if (File.Exists(FilePath))
            {
                var saved = File.ReadAllText(FilePath).Trim();
                if (saved is "ru" or "en") return saved;
            }
        }
        catch (IOException) { }

        var sys = CultureInfo.CurrentUICulture.TwoLetterISOLanguageName;
        return sys is "ru" or "uk" or "be" or "kk" ? "ru" : "en";
    }

    public static string T(string ru, string en) => IsEnglish ? en : ru;

    public static string AppTitle => "DBD TRACKER";
    public static string Refresh => T("Обновить", "Refresh");
    public static string Error => T("Ошибка", "Error");
    public static string Ok => "OK";
    public static string Cancel => T("Отмена", "Cancel");

    public static string NavMyProfile => T("Мой профиль", "My profile");
    public static string NavSearch => T("Поиск игрока", "Find player");
    public static string NavSettings => T("Настройки", "Settings");
    public static string NavSignOut => T("Выйти", "Sign out");
    public static string NavSignIn => T("Войти через Steam", "Sign in with Steam");

    public static string LoginSubtitle => T("Статистика Dead by Daylight", "Dead by Daylight stats");
    public static string LoginButton => T("Войти через Steam", "Sign in with Steam");
    public static string LoginGuest => T("Продолжить без входа (только поиск)", "Continue without signing in (search only)");
    public static string LoginWaiting => T("Заверши вход в открывшемся браузере…", "Finish signing in in your browser…");
    public static string LoginFailed => T("Не удалось войти", "Sign-in failed");
    public static string LoginNote => T(
        "Пароль вводится только на сайте Steam. Приложение получает лишь твой SteamID. Данные берутся из открытого профиля Steam.",
        "Your password is entered only on the Steam website. The app only receives your SteamID. Data comes from your public Steam profile.");

    public static string SearchTitle => T("Поиск игрока", "Find a player");
    public static string SearchHint => T(
        "Вставь ссылку на профиль Steam, SteamID64 или ник из ссылки (steamcommunity.com/id/ник).",
        "Paste a Steam profile link, a SteamID64 or the custom name from the link (steamcommunity.com/id/name).");
    public static string SearchButton => T("Найти", "Search");
    public static string SearchNotFound => T("Не нашли", "Not found");

    public static string SteamProfile => T("Профиль в Steam", "Steam profile");
    public static string SteamAchievements => T("Достижения в Steam", "Achievements on Steam");
    public static string KeyHintTitle => T("Хочешь точные цифры?", "Want exact numbers?");
    public static string KeyHintText => T(
        "Добавь свой ключ Steam API в Настройках, и здесь появятся побеги, генераторы, жертвы и другие счётчики.",
        "Add your Steam API key in Settings to see escapes, generators, sacrifices and other counters here.");
    public static string KeyHintButton => T("Открыть настройки", "Open settings");
    public static string DetailedUnavailable => T("Точная статистика недоступна", "Detailed stats unavailable");
    public static string AchievementsUnavailable => T("Достижения недоступны", "Achievements unavailable");
    public static string SectionAchievements => T("Достижения", "Achievements");
    public static string SectionMilestones => T("Вехи", "Milestones");
    public static string SectionRecent => T("Последние достижения", "Recent achievements");

    public static string SettingsTitle => T("Настройки", "Settings");
    public static string LanguageTitle => T("Язык", "Language");
    public static string LanguageHint => T("Язык интерфейса приложения.", "App interface language.");
    public static string KeyTitle => T("Ключ Steam Web API", "Steam Web API key");
    public static string KeyText => T(
        "С ключом приложение показывает точные цифры: побеги, генераторы, жертвы, проверки навыка, очки крови и прирост за день. Ключ хранится зашифрованным только на этом компьютере.",
        "With a key the app shows exact numbers: escapes, generators, sacrifices, skill checks, bloodpoints and daily gains. The key is stored encrypted on this computer only.");
    public static string KeyHowTo => T("Как получить (1 минута):", "How to get one (1 minute):");
    public static string KeyStep1 => T("1. Открой страницу ключа Steam (кнопка ниже) и войди.", "1. Open the Steam key page (button below) and sign in.");
    public static string KeyStep2 => T("2. Поставь галочку, нажми «Register» и скопируй ключ (32 символа).", "2. Tick the box, click \"Register\" and copy the key (32 characters).");
    public static string KeyOpenPage => T("Открыть steamcommunity.com/dev/apikey", "Open steamcommunity.com/dev/apikey");
    public static string KeyPlaceholder => T("Вставь ключ сюда", "Paste your key here");
    public static string KeySave => T("Проверить и сохранить", "Verify and save");
    public static string KeyRemove => T("Удалить ключ", "Remove key");
    public static string KeySaved => T("Ключ сохранён ✔", "Key saved ✔");
    public static string KeyNotSet => T("Ключ не задан — показываются только часы и достижения.", "No key — only hours and achievements are shown.");
    public static string LogTitle => T("Если что-то сломалось", "If something breaks");
    public static string LogText => T("Ошибки записываются в файл. Его можно открыть и прислать.", "Errors are written to a log file you can open and send.");
    public static string LogOpen => T("Открыть журнал ошибок", "Open error log");

    public static string NavMini => T("Мини-окно", "Mini window");
    public static string TrayTooltip => T("DBD Tracker — клик: мини-окно", "DBD Tracker — click: mini window");
    public static string TrayMini => T("Мини-окно\tCtrl+Shift+D", "Mini window\tCtrl+Shift+D");
    public static string TrayOpen => T("Открыть DBD Tracker", "Open DBD Tracker");
    public static string TrayExit => T("Выход", "Exit");
    public static string TrayBalloonTitle => T("DBD Tracker работает в трее", "DBD Tracker is in the tray");
    public static string TrayBalloonText => T(
        "Нажми на значок или Ctrl+Shift+D, чтобы открыть мини-окно. Выйти — правый клик → Выход.",
        "Click the icon or press Ctrl+Shift+D to open the mini window. To quit: right-click → Exit.");

    public static string MiniPlaceholder => T("Ссылка на профиль Steam", "Steam profile link");
    public static string MiniPaste => T("Вставить из буфера", "Paste from clipboard");
    public static string MiniSearch => T("Найти", "Search");
    public static string MiniOpenFull => T("Открыть полностью", "Open full view");
    public static string MiniPin => T("Поверх всех окон", "Always on top");
    public static string MiniCustomize => T("Настроить карточки", "Customize cards");
    public static string MiniStatsTitle => T("Мини-окно: что показывать", "Mini window: what to show");
    public static string MiniStatsHint => T(
        "Выбери, что видеть при осмотре игрока в лобби. Первые 4 показываются крупными карточками, порядок меняется стрелками.",
        "Choose what you see when checking a player in the lobby. The first 4 are shown as large cards; reorder with the arrows.");
    public static string MiniStatsSelected => T("Показываются (по порядку)", "Shown (in order)");
    public static string MiniStatsAll => T("Все категории", "All categories");
    public static string MiniStatsEmpty => T("Ничего не выбрано — отметь пункты ниже.", "Nothing selected — tick items below.");
    public static string MoveUp => T("Выше", "Move up");
    public static string MoveDown => T("Ниже", "Move down");
    public static string Remove => T("Убрать", "Remove");
    public static string MiniStatsReset => T("Вернуть по умолчанию", "Reset to defaults");
    public static string MiniStatsNeedsKey => T("Ранги и точные цифры работают только с ключом Steam API.", "Grades and exact numbers require a Steam API key.");
    public static string MiniRecent => T("Недавние", "Recent");
    public static string MiniClearRecent => T("Очистить", "Clear");
    public static string MiniEmptyTitle => T("Вставь ссылку на профиль", "Paste a profile link");
    public static string MiniEmptyText => T(
        "Скопируй ссылку на профиль игрока в Steam и нажми Ctrl+V, затем Enter. Esc — спрятать окно.",
        "Copy a player's Steam profile link, press Ctrl+V, then Enter. Esc hides this window.");

    public static string TraySectionTitle => T("Трей и мини-окно", "Tray and mini window");
    public static string CloseToTrayTitle => T("Сворачивать в трей при закрытии", "Minimize to tray on close");
    public static string CloseToTrayHint => T(
        "Крестик прячет программу в трей, а не закрывает её. Выйти — правый клик по значку → Выход.",
        "The close button hides the app to the tray instead of quitting. To quit: right-click the icon → Exit.");
    public static string HotkeyTitle => T("Горячая клавиша Ctrl+Shift+D", "Hotkey Ctrl+Shift+D");
    public static string HotkeyHint => T("Открывает и прячет мини-окно из любой программы.", "Shows and hides the mini window from any app.");
    public static string HotkeyBusy => T("Это сочетание уже занято другой программой.", "This shortcut is already used by another app.");
    public static string AutoPasteTitle => T("Автовставка ссылки из буфера", "Auto-paste link from clipboard");
    public static string AutoPasteHint => T(
        "При открытии мини-окна скопированная ссылка Steam подставляется и ищется сама.",
        "When the mini window opens, a copied Steam link is pasted and searched automatically.");
    public static string AutostartTitle => T("Запускать вместе с Windows", "Start with Windows");
    public static string AutostartHint => T("Программа стартует свёрнутой в трей.", "The app starts minimized to the tray.");
    public static string FullscreenNote => T(
        "Мини-окно видно поверх игры, только если DBD запущена в режиме «Без рамки» или «В окне». Поверх эксклюзивного полноэкранного режима Windows окна не показывает.",
        "The mini window shows over the game only in Borderless or Windowed mode. Windows can't draw windows over exclusive fullscreen.");

    public static string GroupSurvivor => T("Выживший", "Survivor");
    public static string GroupKiller => T("Убийца", "Killer");
    public static string GroupGeneral => T("Общее", "General");
    public static string GroupOther => T("Прочее", "Other");

    public static string StatusOnline => T("В сети", "Online");
    public static string StatusInGame => T("В игре", "In game");
    public static string StatusOffline => T("Не в сети", "Offline");
    public static string ProfilePrivate => T(" · профиль закрыт", " · private profile");

    public static string FormatDate(DateTimeOffset? d) =>
        d is { } v ? v.ToLocalTime().ToString(IsEnglish ? "MMM d, yyyy" : "d MMM yyyy", Culture) : "";

    public static string FormatNumber(double v) =>
        v == Math.Floor(v) ? v.ToString("N0", Culture) : v.ToString("N1", Culture);
}
