using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Windows.Foundation;

namespace DbdTracker.App.Controls;

public sealed class UniformWrapPanel : Panel
{
    public static readonly DependencyProperty MinItemWidthProperty = DependencyProperty.Register(
        nameof(MinItemWidth), typeof(double), typeof(UniformWrapPanel), new PropertyMetadata(200d, OnLayoutChanged));

    public static readonly DependencyProperty ColumnSpacingProperty = DependencyProperty.Register(
        nameof(ColumnSpacing), typeof(double), typeof(UniformWrapPanel), new PropertyMetadata(12d, OnLayoutChanged));

    public static readonly DependencyProperty RowSpacingProperty = DependencyProperty.Register(
        nameof(RowSpacing), typeof(double), typeof(UniformWrapPanel), new PropertyMetadata(12d, OnLayoutChanged));

    public double MinItemWidth
    {
        get => (double)GetValue(MinItemWidthProperty);
        set => SetValue(MinItemWidthProperty, value);
    }

    public double ColumnSpacing
    {
        get => (double)GetValue(ColumnSpacingProperty);
        set => SetValue(ColumnSpacingProperty, value);
    }

    public double RowSpacing
    {
        get => (double)GetValue(RowSpacingProperty);
        set => SetValue(RowSpacingProperty, value);
    }

    private static void OnLayoutChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) =>
        ((UniformWrapPanel)d).InvalidateMeasure();

    private List<UIElement> Visible() => Children.Where(c => c.Visibility == Visibility.Visible).ToList();

    private (int Columns, double ItemWidth) Compute(double width, int count)
    {
        if (count == 0) return (1, 0);

        var min = Math.Max(1, MinItemWidth);
        if (double.IsInfinity(width) || double.IsNaN(width) || width <= 0)
            return (count, min);

        var cols = Math.Max(1, (int)((width + ColumnSpacing) / (min + ColumnSpacing)));
        var itemWidth = Math.Max(0, (width - ColumnSpacing * (cols - 1)) / cols);
        return (cols, itemWidth);
    }

    protected override Size MeasureOverride(Size availableSize)
    {
        var items = Visible();
        foreach (var hidden in Children.Where(c => c.Visibility != Visibility.Visible))
            hidden.Measure(new Size(0, 0));

        var (cols, itemWidth) = Compute(availableSize.Width, items.Count);
        double total = 0, rowHeight = 0;
        var index = 0;

        foreach (var child in items)
        {
            child.Measure(new Size(itemWidth, double.PositiveInfinity));
            rowHeight = Math.Max(rowHeight, child.DesiredSize.Height);

            if (++index % cols == 0)
            {
                total += rowHeight + RowSpacing;
                rowHeight = 0;
            }
        }

        if (index % cols != 0) total += rowHeight;
        else if (index > 0) total -= RowSpacing;

        var width = double.IsInfinity(availableSize.Width)
            ? cols * itemWidth + (cols - 1) * ColumnSpacing
            : availableSize.Width;
        return new Size(width, Math.Max(0, total));
    }

    protected override Size ArrangeOverride(Size finalSize)
    {
        var items = Visible();
        foreach (var hidden in Children.Where(c => c.Visibility != Visibility.Visible))
            hidden.Arrange(new Rect(0, 0, 0, 0));

        var (cols, itemWidth) = Compute(finalSize.Width, items.Count);
        double y = 0;

        for (var start = 0; start < items.Count; start += cols)
        {
            var end = Math.Min(start + cols, items.Count);
            double rowHeight = 0;
            for (var i = start; i < end; i++)
                rowHeight = Math.Max(rowHeight, items[i].DesiredSize.Height);

            for (var i = start; i < end; i++)
            {
                var x = (i - start) * (itemWidth + ColumnSpacing);
                items[i].Arrange(new Rect(x, y, itemWidth, rowHeight));
            }

            y += rowHeight + RowSpacing;
        }

        return finalSize;
    }
}
