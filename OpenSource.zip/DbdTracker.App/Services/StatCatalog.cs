using DbdTracker.App.Localization;
using DbdTracker.App.Models;

namespace DbdTracker.App.Services;

public static class StatCatalog
{
    private enum Group { Survivor, Killer, General, Other }

    private sealed record Def(string Key, string Ru, string En, Group Group)
    {
        public string Label => L.T(Ru, En);
    }

    private static readonly Def[] Defs =
    [

        new("DBD_Escape", "Побеги", "Escapes", Group.Survivor),
        new("DBD_EscapeThroughHatch", "Побеги через люк", "Hatch escapes", Group.Survivor),
        new("DBD_EscapeKO", "Побеги ползком", "Escapes while crawling", Group.Survivor),
        new("DBD_HookedAndEscape", "Побеги после самоснятия", "Escapes after self-unhook", Group.Survivor),
        new("DBD_DLC8_Camper_Stat1", "Побеги после падения", "Escapes after being downed", Group.Survivor),
        new("DBD_GeneratorPct_float", "Починено генераторов", "Generators repaired", Group.Survivor),
        new("DBD_Camper8_Stat1", "Починено повреждённых генераторов", "Damaged generators repaired", Group.Survivor),
        new("DBD_HealPct_float", "Вылечено выживших", "Survivors healed", Group.Survivor),
        new("DBD_UnhookOrHeal", "Спасения с крюка и подъёмы", "Unhooks and dying heals", Group.Survivor),
        new("DBD_UnhookOrHeal_PostExit", "Спасения в эндгейме", "Saves in endgame", Group.Survivor),
        new("DBD_Chapter9_Camper_Stat1", "Снялся с крюка сам", "Self-unhooks", Group.Survivor),
        new("DBD_HitNearHook", "Защитные удары после снятия", "Protection hits after unhook", Group.Survivor),
        new("DBD_Chapter14_Camper_Stat1", "Защитные удары (убийца с ношей)", "Protection hits while killer carries", Group.Survivor),
        new("DBD_Chapter12_Camper_Stat1", "Вырвался из рук убийцы", "Wiggled free", Group.Survivor),
        new("DBD_SkillCheckSuccess", "Успешные проверки навыка", "Successful skill checks", Group.Survivor),
        new("DBD_DLC7_Camper_Stat1", "Обыскано сундуков", "Chests searched", Group.Survivor),
        new("DBD_DLC7_Camper_Stat2", "Открыто ворот", "Exit gates opened", Group.Survivor),
        new("DBD_DLC3_Camper_Stat1", "Очищено тотемов проклятий", "Hex totems cleansed", Group.Survivor),
        new("DBD_Chapter10_Camper_Stat1", "Сломано крюков", "Hooks sabotaged", Group.Survivor),
        new("DBD_Camper8_Stat2", "Прыжков в погоне", "Vaults in chase", Group.Survivor),
        new("DBD_DLC9_Camper_Stat1", "Прыжков с промахом убийцы", "Vaults making the killer miss", Group.Survivor),
        new("DBD_CamperNewItem", "Побегов с новым предметом", "Escapes with a new item", Group.Survivor),
        new("DBD_CamperEscapeWithItemFrom", "Побегов с чужим предметом", "Escapes with someone else's item", Group.Survivor),
        new("DBD_CamperMaxScoreByCategory", "Идеальные игры (5k во всех)", "Perfect games (5k in all)", Group.Survivor),
        new("DBD_CamperFullLoadout", "Матчи с полным снаряжением", "Matches with full loadout", Group.Survivor),

        new("DBD_SacrificedCampers", "Принесено в жертву", "Survivors sacrificed", Group.Killer),
        new("DBD_KilledCampers", "Убито лично (мори и т. п.)", "Survivors killed (mori etc.)", Group.Killer),
        new("DBD_DLC7_Slasher_Stat2", "Принесено Одержимых", "Obsessions sacrificed", Group.Killer),
        new("DBD_DLC8_Slasher_Stat2", "Убито после всех генераторов", "Kills after all gens done", Group.Killer),
        new("DBD_Chapter11_Slasher_Stat1", "Все в жертву до последнего гена", "4K before last gen", Group.Killer),
        new("DBD_DLC6_Slasher_Stat2", "Повешено в подвале", "Basement hooks", Group.Killer),
        new("DBD_Chapter13_Slasher_Stat1", "Закрыто люков", "Hatches closed", Group.Killer),
        new("DBD_Chapter12_Slasher_Stat1", "Схвачено у генератора", "Grabs off generators", Group.Killer),
        new("DBD_Chapter15_Slasher_Stat2", "Схвачено у тотема", "Grabs off totems", Group.Killer),
        new("DBD_Chapter10_Slasher_Stat1", "Ударов с выжившим на плече", "Hits while carrying", Group.Killer),
        new("DBD_Chapter9_Slasher_Stat1", "Ударов после сброса паллеты", "Hits after pallet drop", Group.Killer),
        new("DBD_SlasherMaxScoreByCategory", "Идеальные игры (5k во всех)", "Perfect games (5k in all)", Group.Killer),
        new("DBD_SlasherFullLoadout", "Матчи с полным снаряжением", "Matches with full loadout", Group.Killer),

        new("DBD_BloodwebPoints", "Очки крови", "Bloodpoints", Group.General),
        new("DBD_UnlockRanking", "Повышений ранга", "Rank-ups", Group.General),
        new("DBD_Event1_Stat3", "Таинственных ящиков в паутине", "Mystery boxes opened", Group.General),
    ];

    public static IEnumerable<(string Key, string Label, string GroupTitle)> All
    {
        get
        {
            foreach (var g in GroupOrder)
            {
                if (g == Group.Killer)
                    yield return ("calc_total_kills", L.T("Всего убито", "Total kills"), Title(g));
                foreach (var d in Defs.Where(d => d.Group == g))
                    yield return (d.Key, d.Label, Title(g));
            }
        }
    }

    private static readonly Group[] GroupOrder = [Group.Survivor, Group.Killer, Group.General];

    private static string Title(Group g) => g switch
    {
        Group.Survivor => L.GroupSurvivor,
        Group.Killer => L.GroupKiller,
        Group.General => L.GroupGeneral,
        _ => L.GroupOther,
    };

    public static IReadOnlyList<StatGroup> Build(IReadOnlyDictionary<string, double> raw, bool alreadyScaled = false)
    {
        var buckets = GroupOrder.ToDictionary(g => g, _ => new List<Stat>());

        foreach (var d in Defs)
        {
            if (raw.TryGetValue(d.Key, out var v))
            {
                var value = d.Key.EndsWith("_float", StringComparison.Ordinal) ? Math.Floor(v) : v;
                buckets[d.Group].Add(new Stat(d.Key, d.Label, value));
            }
        }

        if (alreadyScaled && raw.TryGetValue("calc_total_kills", out var total))
            buckets[Group.Killer].Insert(0, new Stat("calc_total_kills", L.T("Всего убито", "Total kills"), total));
        else if (raw.TryGetValue("DBD_SacrificedCampers", out var sac) && raw.TryGetValue("DBD_KilledCampers", out var kil))
            buckets[Group.Killer].Insert(0, new Stat("calc_total_kills", L.T("Всего убито", "Total kills"), sac + kil));

        return GroupOrder
            .Where(g => buckets[g].Count > 0)
            .Select(g => new StatGroup(Title(g), buckets[g]))
            .ToList();
    }
}
