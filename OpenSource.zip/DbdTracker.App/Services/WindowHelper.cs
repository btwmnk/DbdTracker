using System.Runtime.InteropServices;
using Microsoft.UI.Windowing;
using Microsoft.UI.Xaml;
using Windows.Graphics;

namespace DbdTracker.App.Services;

public static class WindowHelper
{
    public static IntPtr Handle(Window window) => WinRT.Interop.WindowNative.GetWindowHandle(window);

    public static double Scale(Window window)
    {
        var dpi = GetDpiForWindow(Handle(window));
        return dpi == 0 ? 1.0 : dpi / 96.0;
    }

    public static void ResizeLogical(Window window, int width, int height)
    {
        var scale = Scale(window);
        var w = (int)(width * scale);
        var h = (int)(height * scale);

        var area = DisplayArea.GetFromWindowId(window.AppWindow.Id, DisplayAreaFallback.Primary).WorkArea;
        w = Math.Min(w, (int)(area.Width * 0.95));
        h = Math.Min(h, (int)(area.Height * 0.95));

        window.AppWindow.Resize(new SizeInt32(w, h));
    }

    public static void MoveTopRight(Window window, int marginLogical = 16)
    {
        var area = DisplayArea.GetFromWindowId(window.AppWindow.Id, DisplayAreaFallback.Primary).WorkArea;
        var margin = (int)(marginLogical * Scale(window));
        var size = window.AppWindow.Size;
        window.AppWindow.Move(new PointInt32(area.X + area.Width - size.Width - margin, area.Y + margin));
    }

    public static void BringToFront(Window window)
    {
        if (window.AppWindow.Presenter is OverlappedPresenter { State: OverlappedPresenterState.Minimized } p)
            p.Restore();

        window.AppWindow.Show();
        window.Activate();
        SetForegroundWindow(Handle(window));
    }

    public static void StyleCaptionButtons(Window window)
    {
        var tb = window.AppWindow.TitleBar;
        tb.ButtonBackgroundColor = Microsoft.UI.Colors.Transparent;
        tb.ButtonInactiveBackgroundColor = Microsoft.UI.Colors.Transparent;
        tb.ButtonForegroundColor = Microsoft.UI.Colors.White;
        tb.ButtonInactiveForegroundColor = Windows.UI.Color.FromArgb(0x80, 0xFF, 0xFF, 0xFF);
        tb.ButtonHoverBackgroundColor = Windows.UI.Color.FromArgb(0x22, 0xFF, 0xFF, 0xFF);
        tb.ButtonHoverForegroundColor = Microsoft.UI.Colors.White;
        tb.ButtonPressedBackgroundColor = Windows.UI.Color.FromArgb(0x33, 0xFF, 0xFF, 0xFF);
        tb.ButtonPressedForegroundColor = Microsoft.UI.Colors.White;
    }

    [DllImport("user32.dll")]
    private static extern uint GetDpiForWindow(IntPtr hwnd);

    [DllImport("user32.dll")]
    private static extern bool SetForegroundWindow(IntPtr hWnd);
}
